# API Reference Overview

This reference summarizes the public APIs of the monorepo components and points to the authoritative source files. It complements `DESIGN.md §1-3` (architecture) and `METHODS.md §APIs`. Update all three when signatures or invariants change.

## `crypto/` (Rust crate `synthetic-crypto`)

- `ml_dsa` module
  - `Keypair::generate(seed: &[u8; 48]) -> Keypair`
  - `Keypair::sign(&self, msg: &[u8]) -> Signature`
  - `VerifyKey::verify(&self, msg: &[u8], sig: &Signature) -> Result<()>`
  - Security margin: ML-DSA-65 (Dilithium 3) sized keys (pk 1952 B, expanded compatibility sk 4032 B, sig 3309 B).
- `ml_kem` module
  - `Keypair::encapsulate(&self, rng_seed: &[u8; 32]) -> (Ciphertext, SharedSecret)`
  - `SecretKey::decapsulate(&self, ct: &Ciphertext) -> SharedSecret`
  - Security margin: ML-KEM-1024; shared secrets truncated to 32 bytes.
- `hashes` module
  - `commit_note(message: &[u8], randomness: &[u8]) -> [u8; 48]` (BLAKE3-384 by default) and `commit_note_with(.., CommitmentHash::Sha3)` for SHA3-384 commitments.
  - `sha3_256`, `blake3_256`, `blake3_384`, and Poseidon-style field hashing helpers. `commit_note_with` uses SHA3-384 when requested. BLAKE3-384 is the default digest for commitments/nullifiers, while BLAKE3-256 remains the default for PQ address tagging and other 32-byte identifiers.
  - `derive_nullifier(nk: &[u8; 32], position: u64, rho: &[u8; 32]) -> [u8; 48]` and `derive_prf_key` use the same domain tags.
  - Domain separation constants `b"c"`, `b"nk"`, `b"nf"` are enforced to avoid cross-protocol collisions.

## `circuits/`

- `transaction-circuit` exposes `proof::prove(witness, proving_key) -> TransactionProof` and `proof::verify(proof, verifying_key) -> VerificationReport` on the SmallWood-only production path. Production verification rejects retired backend identifiers, missing proof bytes, and malformed public inputs; commitment/nullifier encodings are 48-byte values with six canonical limbs (validated via `hashing_pq::is_canonical_bytes48`).
- `circuits/disclosure` is retired source and is excluded from shipped executable dependency graphs and release tests.
- `block-circuit` crate aggregates multiple transaction proofs via `BlockCircuit::prove(block_inputs)`.
- `circuits/bench` binary crate (`circuits-bench`) provides `cargo run -p circuits-bench -- --iterations N --prove` to compile circuits, generate witnesses, and optionally verify proofs. Output includes constraint rows, hash rounds, and per-proof latency.

## `consensus/`

- Rust crate `consensus` exposes `BlockBuilder`, ledger-state transition helpers, and PQ signature utilities that miners call w
hen assembling payloads.
- The proof-bearing block boundary is now backend-neutral:
  - `ProofEnvelope { kind, verifier_profile, artifact_bytes }`
  - `TxValidityReceipt { statement_hash, proof_digest, public_inputs_digest, verifier_profile }`
  - `TxValidityArtifact { receipt, proof }`
  - `ConsensusBlock` carries `tx_validity_artifacts` plus an optional `block_artifact` instead of a raw `transaction_proofs` field.
- Import admits only the shipped `RecursiveBlockV2` route. `VerifierRegistry` retains direct research/test adapters for historical recursive and receipt-root artifacts, but proof policy prevents those adapters from becoming block-import routes.
- The consensus crate also exposes the temporary receipt-root backend façade:
  - `experimental_receipt_root_verifier_profile()`
  - `build_experimental_receipt_root_artifact(receipts)`
  - `verify_experimental_receipt_root_artifact(receipts, artifact_bytes)`
  These helpers keep generic layers from importing a backend-specific `superneo-*` crate directly.
- Go benchmarking module `consensus/bench` offers `cmd/netbench`:
  - Flags: `--miners`, `--payload-bytes`, `--pq-signature-bytes`, `--smoke`.
  - Output: JSON summary with `messages_per_second`, `avg_latency_ms`, `pq_signature_bytes` so operators can project miner gossi
p budgets.

## `wallet/`

- Rust crate `wallet` exposes CLI subcommands via `clap` definitions in `wallet/src/bin/wallet.rs`, covering offline helpers and native node RPC flows.
- `wallet payment-proof purge` manages retained outgoing disclosure records. `payment-proof create|verify` are fail-closed compatibility tombstones because no disclosure proof backend ships.
- `wallet node-sync`, `wallet node-daemon`, and `wallet node-send` are the native node RPC paths for live wallets. One-shot commands accept the native node's plaintext `http://` JSON-RPC endpoint as well as `ws://`; subscription-backed daemon mode still requires `ws://`. PQ-only release wallets reject `https://` and `wss://`; put remote access behind an external PQ-safe transport or host control plane.
- Wallet sync falls back to archive providers for ciphertext recovery when hot DA is pruned. Configure `HEGEMON_WALLET_ARCHIVE_WS_URL` or ensure providers are discoverable via `archive_listProviders`.
- `wallet::disclosure::{DisclosurePackage, DisclosureClaim, DisclosureConfirmation, DisclosureProof}` defines the JSON schema and encoding helpers used to serialize/deserialize proof-of-disclosure packages.
- `wallet::TransactionBundle` and shielded-transfer payloads use `binding_hash` (a 64-byte hash commitment), not a signature.
- `wallet/bench` binary crate (`wallet-bench`) accepts `--iterations` and reports note construction/sec, nullifier derivations/sec, and encryption throughput.

## `walletd/`

- `walletd` is a sidecar daemon that speaks newline-delimited JSON over stdin/stdout for GUI clients.
- Requests: `{ id, method, params }`. Responses: `{ id, ok, result?, error?, error_code? }`. `error_code` is snake_case.
- `status.get` returns `protocolVersion`, `capabilities`, `walletMode`, `storePath`, balances, `pending` entries (still in mempool), `recent` confirmed outgoing entries, note summary, `noteDetails` for recovered inbound notes, `noteAccounting` totals by asset/status, and `genesisHash`.
- `sync.once` and `tx.send` mirror the wallet CLI flows without log parsing. `disclosure.list` remains available for local records; `disclosure.create|verify` return an unavailable error and `status.get` reports `capabilities.disclosure = false`.
- Private multisig requests are `multisig.localSignerTag`, `multisig.accountCreate`, `multisig.accountExportPrivate`, `multisig.accountImportPrivate`, `multisig.accountList`, `multisig.noteList`, `multisig.openingExportPrivate`, `multisig.openingImportPrivate`, `multisig.valueLockSubmit`, `multisig.finalPlan`, `multisig.setupSubmit`, `multisig.approvalSubmit`, `multisig.finalSubmit`, `multisig.approvalCreate`, `multisig.approvalImport`, and `multisig.finalize`. The canonical custody flow is value-lock submit, setup submit for the returned `intentDigest`, approval submit until the hidden threshold is reached, then final submit. `multisig.localSignerTag` returns each signer-tag limb as a fixed-width hex string so JavaScript clients do not lose `u64` precision. `multisig.accountCreate` accepts `policySignerTags: [[hex-string; 5]; 1..=6]` and `threshold: 1..=policySignerTags.length`; legacy numeric limbs are still accepted for non-JavaScript callers. The scalar signer-id API is not exposed. The `*Private` methods move encrypted-wallet private descriptors/openings between signer wallets over an operator-controlled off-chain channel and must not be published as transaction data.
- The daemon holds an exclusive `<store>.lock` file to prevent concurrent access to the same wallet store.

## Protocol kernel and shielded family

- `protocol-kernel`
  - `submit_action(envelope)` is the only live public dispatch surface for proof-native protocol actions.
  - `FamilyRoots` stores the active family roots.
  - `KernelGlobalRoot` commits to the family-root map and is part of the live validity shape.

- `protocol-shielded-pool`
  - remains the first kernel family backend for shielded commitments, nullifiers, fee accounting, and proof verification
  - does not expose its state-changing calls as a public runtime dispatch surface
  - still implements the underlying action semantics for:
    - per-transfer shielded proofs
    - batch transfer proofs
    - aggregation-mode markers
    - proven block-batch payloads
    - shielded coinbase minting

## Node RPC endpoints

Hegemon-specific RPC methods exposed on the native JSON-RPC server:

Native HTTP JSON-RPC rejects request bodies above 8 MiB and caps in-flight RPC
requests at 8. Chunk DA sidecar staging uploads rather than sending one large
aggregate JSON body.

- `hegemon_miningStatus() -> MiningStatus`
- `hegemon_startMining(params?: { threads: number }) -> MiningControlResponse`
  - Unsafe-only local/operator control RPC. Requires explicit `--rpc-methods=unsafe`; `auto` resolves to safe-only.
- `hegemon_stopMining() -> MiningControlResponse`
  - Unsafe-only local/operator control RPC. Requires explicit `--rpc-methods=unsafe`; `auto` resolves to safe-only.
- `hegemon_compactJob(params?: { auth_token?: String }) -> CompactJobResponse`
- `hegemon_submitCompactSolution(request: { worker_name: String, job_id: String, nonce: String, auth_token?: String }) -> SubmitPoolShareResponse`
- `hegemon_poolWork(params?: { auth_token?: String }) -> PoolWorkResponse`
- `hegemon_submitPoolShare(request: { worker_name: String, nonce: String, pre_hash: String, parent_hash: String, height: u64, auth_token?: String }) -> SubmitPoolShareResponse`
- `hegemon_poolStatus(params?: { auth_token?: String }) -> PoolStatusResponse`
- `hegemon_submitTransaction(...) -> { success: false, error: String }`
  - Disabled compatibility stub. Wallets and applications must use `hegemon_submitAction` for live native protocol actions.
- `hegemon_consensusStatus() -> ConsensusStatus`
- `hegemon_isValidAnchor(anchor_hex: String) -> bool`
  - Read-only wallet precheck. Accepts a 48-byte commitment-tree root as hex, with or without `0x`, and returns whether the native commitment tree recognizes it.
- `hegemon_telemetry() -> TelemetrySnapshot`
- `hegemon_storageFootprint() -> StorageFootprint`
- `hegemon_nodeConfig() -> NodeConfigSnapshot`
  - Safe RPC returns only chain identity and method-policy fields with `redacted=true`.
  - Unsafe local/operator RPC returns base path, listen addresses, bootstrap nodes, PQ verbosity, and peer limits.
- `hegemon_peerList() -> Vec<PeerDetail>` (connected PQ peers with address, direction, best height/hash, last-seen seconds)
  - Unsafe-only local/operator topology RPC.
- `hegemon_peerGraph() -> PeerGraphSnapshot` (direct peers plus reported peers from discovery)
  - Unsafe-only local/operator topology RPC.

Compact mining RPC notes:
- `hegemon_compactJob` is the preferred compact-job miner surface. It exposes a stable `job_id`, `pre_hash`, `parent_hash`, and share/network targets without assuming an implicit `u64` nonce.
- `hegemon_submitCompactSolution` accepts a 32-byte nonce (`0x`-prefixed hex) plus the advertised `job_id`.

Legacy / experimental pool-worker RPC notes:
- `hegemon_poolWork` exposes the current authoring template to pooled hash workers.
- `hegemon_submitPoolShare` remains as a compatibility path and now also accepts a 32-byte nonce (`0x`-prefixed hex); full-target solutions are forwarded into the mining coordinator.
- `hegemon_poolStatus` reports aggregate and per-worker share accounting for the current process.
- These pool-worker RPCs are not part of the current default desktop or shipped `RecursiveBlock` operator flow. They remain in-tree for compatibility and experiments.

`CompactJobResponse` fields:
- `available: bool`
- `job_id: Option<String>` (hex)
- `height: Option<u64>`
- `pre_hash: Option<String>` (hex)
- `parent_hash: Option<String>` (hex)
- `network_bits: Option<u32>` (compact PoW bits)
- `share_bits: Option<u32>` (compact bits; defaults to network difficulty unless `HEGEMON_POOL_SHARE_BITS` is set)
- `reason: Option<String>`

`PoolWorkResponse` fields:
- `available: bool`
- `height: Option<u64>`
- `pre_hash: Option<String>` (hex)
- `parent_hash: Option<String>` (hex)
- `network_difficulty: Option<u32>` (compact PoW bits)
- `share_difficulty: Option<u32>` (compact bits; defaults to network difficulty unless `HEGEMON_POOL_SHARE_BITS` is set)
- `reason: Option<String>`

`SubmitPoolShareResponse` fields:
- `accepted: bool`
- `block_candidate: bool`
- `network_target_met: bool`
- `error: Option<String>`
- `accepted_shares: u64`
- `rejected_shares: u64`
- `worker_accepted_shares: u64`
- `worker_rejected_shares: u64`

`PoolStatusResponse` fields:
- `available: bool`
- `network_difficulty: Option<u32>`
- `share_difficulty: Option<u32>`
- `accepted_shares: u64`
- `rejected_shares: u64`
- `worker_count: usize`
- `workers: Vec<PoolWorkerStatusEntry>`

`PoolWorkerStatusEntry` fields:
- `worker_name: String`
- `accepted_shares: u64`
- `rejected_shares: u64`
- `block_candidates: u64`
- `payout_fraction_ppm: u64` (accepted-share fraction scaled by 1,000,000)
- `last_share_at_ms: Option<u64>`

`PeerDetail` fields:
- `peer_id: String` (hex)
- `address: String` (`ip:port`)
- `direction: String` (`inbound` | `outbound`)
- `best_height: u64`
- `best_hash: String` (hex)
- `last_seen_secs: u64`

`PeerGraphSnapshot` fields:
- `local_peer_id: String` (hex)
- `peers: Vec<PeerDetail>` (direct peers)
- `reports: Vec<PeerGraphReportSnapshot>`

`PeerGraphReportSnapshot` fields:
- `reporter_peer_id: String` (hex)
- `reporter_address: String` (`ip:port`)
- `reported_at_secs: u64`
- `peers: Vec<PeerGraphPeer>`

`PeerGraphPeer` fields:
- `peer_id: String` (hex)
- `address: String` (`ip:port`)

Archive market RPC methods exposed on the native JSON-RPC server:

- `archive_listProviders() -> Vec<ArchiveProviderEntry>`
- `archive_getProvider(account_id_hex: String) -> Option<ArchiveProviderEntry>`
- `archive_providerCount() -> u32`
- `archive_listContracts(account_id_hex: String) -> Vec<ArchiveContractEntry>`
- `archive_getContract(contract_id: u64) -> Option<ArchiveContractEntry>`

Block validity and data-availability RPC methods exposed by the native node:

- `block_getCommitmentProof(block_hash: H256) -> Option<CommitmentProofResult>`
  - Returns the commitment proof bytes and public inputs for a block, or `null` if the block has no commitment proof (e.g., coinbase-only blocks).
  - `CommitmentProofResult`: `{ proof_bytes: Bytes, public_inputs: CommitmentProofPublicInputs }`
- `da_getChunk(da_root: H256, chunk_index: u32) -> Option<DaChunkResult>`
  - Returns an erasure-coded chunk and its Merkle proof for the given DA root.
  - `DaChunkResult`: `{ chunk: Bytes, merkle_proof: Vec<H256> }`
- `da_getParams() -> DaParams`
  - Returns global DA parameters (chunk size, sample count, encoding scheme).
- `da_submitCiphertexts(request: { ciphertexts: Vec<String> }) -> Vec<SubmitCiphertextsEntry>`
  - Unsafe-only proposer/local staging RPC. Stages ciphertext sidecars for `*_sidecar` shielded submission paths and requires `--rpc-methods=unsafe`. Request-count and staged-capacity admission are Lean-conformance-checked against the production native helper.
  - Staged ciphertext bytes live only in proposer-local RAM; a node restart drops them and clients must restage.
- `da_submitProofs(request: { proofs: Vec<{ binding_hash: String, proof: String }> }) -> Vec<SubmitProofsEntry>`
  - Unsafe-only proposer/local proof staging RPC. Request-count, staged-capacity, proof binding-hash metadata, nonempty proof, and proof byte-cap admission are Lean-conformance-checked against the production native helpers.
  - Large proof batches must be chunked to stay below the native 8 MiB JSON-RPC request-body cap.
  - This upload path canonicalizes the supplied binding hash and response hash, but it does not verify `tx_leaf` proof bytes at upload time. Consensus validity is enforced later when native block artifact verification decodes the artifact and checks the derived binding against the action/candidate context.
  - Staged proof bytes live only in proposer-local RAM; a node restart drops them and clients must restage.
- `da_submitWitnesses(...)`
  - Deliberately disabled. Witness sidecars are rejected because they may contain secret material and must not be uploaded over RPC.

Prepared-artifact discovery RPC methods exposed on the native node:

- `prover_listArtifactAnnouncements() -> Vec<ArtifactAnnouncementResponse>`
- `prover_getCandidateArtifact(artifact_hash: String) -> Option<CandidateArtifactResponse>`

These prover RPCs now expose only reusable prepared artifacts on the live native-only branch. The external work-package / standalone-worker market surface was removed with the dead recursive proof lanes.

Legacy RPC endpoints (`block_getRecursiveProof`, `epoch_*`) are removed. The shipped recursive-block-v2 path is SmallWood-native; recursive epoch proofs remain removed and have no runtime endpoint.

Artifact market RPC notes:

- `prover_listArtifactAnnouncements` returns lightweight metadata for locally prepared candidate artifacts. Each entry includes legacy `proof_mode` plus explicit `proof_kind` and `verifier_profile` fields so clients can distinguish backend family from compatibility transport labels. Remote artifact-protocol announcements are not trusted as authoring inputs.
- `prover_getCandidateArtifact` returns the SCALE-encoded `CandidateArtifact` payload for a locally prepared artifact hash when one is available. The response also includes the artifact’s explicit `proof_kind` and `verifier_profile`. This is a local discovery surface, not a P2P import path.

`ArtifactAnnouncementResponse` fields:
- `artifact_hash: String` (`0x`-prefixed hex)
- `tx_statements_commitment: String` (`0x`-prefixed hex)
- `tx_count: u32`
- `proof_mode: String` (compatibility label: `inline_tx` | `receipt_root` | `recursive_block`)
- `proof_kind: String` (backend-neutral artifact family label)
- `verifier_profile: String` (`0x`-prefixed 48-byte digest)

`CandidateArtifactResponse` fields:
- `artifact_hash: String` (`0x`-prefixed hex)
- `tx_statements_commitment: String` (`0x`-prefixed hex)
- `tx_count: u32`
- `proof_kind: String`
- `verifier_profile: String` (`0x`-prefixed 48-byte digest)
- `candidate_txs: Vec<String>` (SCALE-encoded extrinsics as `0x` hex)
- `payload: String` (full SCALE-encoded `CandidateArtifact` as `0x` hex)

## Documentation hooks

Every module README now contains a **Doc Sync** section referencing this file plus `DESIGN.md` and `METHODS.md`. When adding a new API surface, ensure:

1. Function signature and expected behavior are documented here.
2. DESIGN.md explains how it fits the architecture.
3. METHODS.md instructs operators/testers how to exercise it.

Failure to update all three will cause CI docs checks (see `.github/workflows/ci.yml`) to fail.
