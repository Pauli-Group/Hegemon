# Threat Model

This document explains the attacker capabilities and design assumptions for each subsystem. Keep it synchronized with `DESIGN.md §0-3` and `METHODS.md §Threat Monitoring` whenever behavior or mitigations change.

## Global assumptions

- **Post-quantum only**: Attackers may possess Shor-class quantum computers capable of collapsing classical public-key systems. We therefore forbid ECC/RSA and rely on ML-DSA/SLH-DSA signatures, ML-KEM encryption, 256-bit symmetric primitives, and 48-byte (384-bit) digests for commitments and Merkle roots. Generic quantum search remains a conservative sizing consideration for the symmetric/hash layer, not the primary protocol threat.
- **Transparent proving**: There is no trusted setup; proving soundness relies solely on collision resistance of the STARK-friendly hashes described in `DESIGN.md §2`. Compromise of a setup ceremony is out-of-scope because none exists.
- **Adaptive adversaries**: Attackers can corrupt miners, mining pools, or wallets after observing traffic. Key rotation, nullifier privacy, and block template integrity must hold even with partial compromise.
- **Proof-of-work fairness**: Hash-rate swings and rented rigs are assumed. Difficulty targeting plus share accounting must resist sudden 51% bursts for at least 10 minutes while alerts propagate to pool maintainers.

## Component-specific threats

### `crypto/`

- **Keygen misuse**: Attackers might attempt to bias RNGs or turn public transcripts into predictable key material. Production KEM encapsulation and identity/key generation use OS entropy; explicit deterministic seeds are test-only fixtures and must never be derived from public transcripts.
- **Serialization downgrade**: Incorrect key lengths lead to acceptance of weak keys. All APIs perform length checks and return errors that bubble up to consensus/wallet callers.

### `circuits/`

- **Soundness breaks via stale constraints**: Transaction/block circuits must include the latest nullifier/account rules. Circuit README + benchmarking harness describe how to recompile constraints and run proofs.
- **Witness leakage**: Benchmarks never persist witness data to disk; they scrub buffers after proof verification to prevent info leaks during profiling.
- **Proof bypass**: Production verification rejects missing STARK bytes or public inputs; no legacy/fast paths are available in production builds.
- **Encoding malleability**: Commitments/nullifiers are 48-byte encodings of six field limbs; any limb ≥ field modulus is rejected to avoid alternate encodings.

### `network/`

- **Peer impersonation**: PQ transport identities must be derived from secret seeds stored with restrictive permissions (0600) or supplied via secure env overrides; seeds must never be derived from public peer IDs to prevent key prediction.

### `consensus/`

- **Network DoS**: Attackers flood PQ-sized signatures and large STARK proofs. The Go net benchmark evaluates miner and pool throughput budgets with inflated payloads, and `METHODS.md` documents required admission-control thresholds for share telemetry.
- **Native RPC parser DoS**: External JSON-RPC listeners must reject request bodies above 8 MiB and cap concurrent in-flight RPC requests at 8 before JSON parsing can fan out resource use. DA sidecar proof batches are chunkable and must not rely on one large aggregate JSON upload.
- **Forking via outdated PQ params**: Consensus nodes pin ML-DSA and ML-KEM parameter sets and reject blocks signed with unknown variants so malicious pools cannot replay stale templates.
- **Miner impersonation**: Share submissions must be signed with approved miner identities; consensus rejects unbound identities even if the PoW difficulty is valid.
- **Aggregation proof malleability**: Outer proofs must be bound to the exact inner proofs/public inputs; nodes recompute recursion public inputs from transaction proofs and verify aggregation proofs with explicit public values, rejecting missing or mismatched proofs.

### `wallet/`

- **View-key compromise**: Full viewing keys include a view-derived nullifier key (`view_nf`) for spentness tracking but do not embed `sk_spend`; compromise exposes nullifier tracking but not extrinsic signing keys.
- **Metadata leakage**: Wallet bench stresses note batching to keep `rho` diversifiers unpredictable even under load.
- **Disclosure package leakage**: Payment-proof packages include value, asset id, recipient address, commitment, and anchor. Wallet stores encrypt outgoing disclosure records and CLI verification enforces canonical encodings, genesis-hash checks, and on-chain anchor validation to limit replay and tampering risks.

## Security margins

- **Signatures**: Target ≥ 128-bit PQ security (ML-DSA-65 / SLH-DSA-128f). Keys larger than spec are rejected.
- **KEM**: ML-KEM-1024 for note encryption and PQ transport handshake. Shared secrets truncated to 256 bits of entropy.
- **Hashes**: SHA-256/BLAKE3 externally, Poseidon2 field hash internally (width 12, rate 6, capacity 6, 48-byte outputs).
- **Proving**: FRI parameters are set for ≥128-bit engineering soundness (log_blowup 4, num_queries 32, no grinding).

When implementation shifts any of these values, update this document alongside the relevant design/method sections.
