# Proof Verification Hardening and Consensus Integrity

This ExecPlan is a living document. The sections `Progress`, `Surprises & Discoveries`, `Decision Log`, and `Outcomes & Retrospective` must be kept up to date as work proceeds.

Reference: `.agent/PLANS.md` defines the ExecPlan format and maintenance requirements. This document must be maintained in accordance with that file.

## Purpose / Big Picture

After this change, the node enforces real cryptographic proof verification for shielded transfers and settlement batches, rejects malformed or non-canonical nullifiers and commitments, and enforces PoW timestamp rules during import. A user can prove this by submitting a valid shielded transfer that succeeds, submitting a tampered proof that fails, and observing that a future-dated block is rejected. This aligns the running software with the architecture described in `DESIGN.md` and `METHODS.md` without relying on mock or structural-only verification.

## Progress

- [x] (2025-01-15T00:00Z) Drafted ExecPlan after reviewing `DESIGN.md`, `METHODS.md`, and current verifier implementations.
- [x] (2025-01-15T00:00Z) Aligned runtime/pallet limits to 2/2 and updated mocks/tests.
- [x] (2025-01-15T00:00Z) Added tamper-reject tests for non-canonical inputs/value balance and enforced canonical input checks in the shielded verifier.
- [x] (2025-01-15T00:00Z) Audited production feature flags to disable AcceptAllProofs and require `stark-verify`.
- [x] (2025-01-15T00:00Z) Created `circuits/transaction-core` and refactored the transaction circuit to re-export shared core modules.
- [x] (2025-01-15T00:00Z) Wired the shielded-pool verifier to transaction-core and padded STARK public inputs for verification.
- [x] (2025-01-15T00:00Z) Implemented full transaction AIR constraints, updated prover/witness, and aligned RPO verifier + tests with active flags and value-balance binding.
- [x] (2025-01-15T00:00Z) Bound value balance + fee into STARK public inputs and binding signature; updated pallet verifier, extrinsic inputs, and wallet/node plumbing to reject zero padding and require canonical non-zero inputs.
- [x] (2025-12-19T01:32Z) Update recursive proof pipeline to the new transaction proof shape and refresh `RECURSIVE_PROOFS_EXECPLAN.md` (proof hash now binds proof bytes + public inputs; batch proofs included).
- [x] (2025-12-19T02:08Z) Implement settlement proof verification (settlement STARK circuit + verifier wiring + canonical commitment/nullifier encoding).
- [x] (2025-12-19T01:32Z) Harden PoW import checks and PQ identity generation (proper pre-hash, timestamp inherents restored, zero-seed fallback removed).
- [x] (2025-12-19T02:36Z) Fix settlement circuit constraint degrees and pallet hash conversion bounds; `cargo test -p settlement-circuit` and `cargo test -p pallet-settlement` now pass.
- [x] (2025-12-19T03:55Z) Fix transaction AIR degree mismatches by removing constant-column constraints, adding accumulator transitions + row masks, and rebinding fee/value balance at the final enforcement row.
- [x] (2025-12-19T03:55Z) Run validation for `cargo test -p transaction-circuit`, `cargo test -p settlement-circuit`, and `cargo test -p pallet-settlement`.
- [x] (2025-12-19T04:02Z) Run validation for `cargo test -p pallet-shielded-pool` and `cargo test -p epoch-circuit`.
- [x] (2025-12-19T04:07Z) Update METHODS/API docs for transaction public inputs, MASP selectors, and current circuit APIs.
- [x] (2025-12-19T04:07Z) Update documentation and run validation (completed: DESIGN/METHODS/API updates for settlement proofs; transaction/settlement/pallet-shielded-pool/epoch tests; docs).
- [x] (2025-12-19T05:23Z) Run CI-equivalent checks (fmt, clippy, workspace tests, runtime build/benchmarks, release node build, circuits/wallet benches, security/adversarial suites, go netbench, clang-format) and fix no_std/clippy regressions.

## Surprises & Discoveries

- (2025-01-15) The value-balance tamper test currently passes verification because STARK public inputs do not include value_balance; binding must be added in the circuit/core.
- (2025-01-15) Wallet/node submission paths assumed padded nullifiers/commitments; active-flag public inputs required filtering active entries and adding fee into the binding signature message.
- (2025-12-19) Settlement AIR debug-degree checks flagged hold constraints for all-zero batches; dropping hold constraints avoids degree collapse while keeping absorb-only inputs sound.
- (2025-12-19) Winterfell debug degree checks surfaced that constant columns make constraint polynomials identically zero; transaction-circuit proofs failed with "transition constraint degrees didn't match" until we made metadata/accumulator columns non-constant via sentinel rows and masked enforcement.
- (2025-12-19) Local macOS CI runs required `LIBCLANG_PATH`/`DYLD_LIBRARY_PATH` for RocksDB bindgen and installing Go for netbench tests.

## Decision Log

- Decision: Introduce a shared, no_std transaction-core crate so the prover and on-chain verifier share constants, hashing, AIR, and public input encoding.
  Rationale: The runtime cannot depend on std, and using a shared core is the only way to prevent drift between proving and verification logic.
  Date/Author: 2025-01-15 / Codex

- Decision: Align runtime limits to the transaction circuit's MAX_INPUTS/MAX_OUTPUTS before expanding circuit capacity.
  Rationale: The circuit currently supports 2 inputs/outputs, while runtime accepts 4; this mismatch allows unverified data to pass and must be eliminated before expanding capacity.
  Date/Author: 2025-01-15 / Codex

- Decision: Fail closed for settlement proofs until a concrete settlement circuit is available.
  Rationale: Structural-only verification is not compatible with the security goals in `DESIGN.md` and `METHODS.md`.
  Date/Author: 2025-01-15 / Codex

- Decision: Do not purge the chain as part of this plan. Use new base paths or `--tmp` when testing.
  Rationale: The user explicitly requested no purge; testing can be done on ephemeral chains.
  Date/Author: 2025-01-15 / Codex

- Decision: Bind epoch proof hashes to proof bytes plus the public inputs required for verification (including batch proofs).
  Rationale: Proof bytes alone do not identify the verified statement; inclusion proofs and recursive pipelines must commit to anchor/nullifiers/commitments/fee/value balance (and batch metadata) to avoid ambiguity.
  Date/Author: 2025-12-19 / Codex

- Decision: Remove the PQ identity zero-seed fallback and fail fast if key generation fails.
  Rationale: Using an all-zero fallback undermines node identity guarantees and masks critical entropy failures; production nodes must not silently degrade.
  Date/Author: 2025-12-19 / Codex

- Decision: Define settlement commitments as Poseidon hash chains over instruction counts, instruction IDs, and nullifiers with canonical 64-bit encodings.
  Rationale: Settlement proofs must bind to concrete batch contents using a hash-friendly STARK primitive without relying on arbitrary 256-bit encodings.
  Date/Author: 2025-12-19 / Codex

- Decision: Drop settlement input-hold constraints and reorder transition degree declarations to match absorb/hash/copy ordering.
  Rationale: Inputs only affect the absorb step; hold constraints were redundant and could collapse transition degrees for all-zero batches in debug builds.
  Date/Author: 2025-12-19 / Codex

- Decision: Replace transaction constant-column constraints with sentinel rows and first-row/final-row masks, and enforce balance at the last transition row (trace_len - 2).
  Rationale: Winterfell debug checks require non-zero constraint polynomials; constant columns collapsed degrees to zero, and transition constraints skip the last row.
  Date/Author: 2025-12-19 / Codex

## Outcomes & Retrospective

Completed proof-verification hardening across transaction, settlement, shielded-pool, and epoch circuits. The transaction AIR now enforces balance via slot accumulators and final-row binding while avoiding debug-degree collapses, settlement verification is wired with canonical encoding, and PoW import + PQ identity hardening is in place. All targeted tests (`transaction-circuit`, `settlement-circuit`, `pallet-settlement`, `pallet-shielded-pool`, `epoch-circuit`) pass. Documentation now reflects current transaction public inputs, MASP selectors, and STARK APIs. Remaining work is outside this plan (e.g., in-circuit range checks and block-level proof aggregation).

## Context and Orientation

The transaction proof system lives in `circuits/transaction`. The on-chain verifier for shielded transfers is in `pallets/shielded-pool/src/verifier.rs`, and runtime limits are in `runtime/src/lib.rs`. Recursive and epoch proof aggregation is in `circuits/epoch`, with the current plan in `.agent/RECURSIVE_PROOFS_EXECPLAN.md`. Settlement proof handling is in `pallets/settlement/src/lib.rs`. The node import pipeline is in `node/src/substrate/service.rs` and `node/src/substrate/block_import.rs`.

A STARK proof is a hash-based proof generated by Winterfell. The AIR is the algebraic definition of what the proof must satisfy. Public inputs are the values committed to by the proof and checked by the verifier. Canonical encoding means the 32-byte nullifier or commitment must be a zero-extended 64-bit field element so two byte strings cannot map to the same field element.

Winterfell constraints that matter here are: trace width must not exceed 255 columns, blowup factor must be at least 16, and constraint degrees must be described exactly or Winterfell will panic in debug builds. The plan below keeps trace width small by streaming data across cycles rather than adding columns.

## Plan of Work

We will first unify the transaction circuit and on-chain verifier by creating a no_std transaction-core crate that owns the constants, hashing, AIR definition, and public-input encoding. The existing `circuits/transaction` crate will use this core for proving, and `pallets/shielded-pool` will use it for verification. Runtime limits will be reduced to the circuit's current capacity of 2 inputs and 2 outputs to eliminate the current mismatch.

Next we will implement full transaction constraints in the AIR, including nullifier derivation, Merkle path verification, commitment correctness, balance rules, and range checks. This will require new trace layout rules and a prover update to populate new columns. We will add tamper-reject tests to prove cryptographic enforcement.

Then we will replace the pallet verifier with the shared cryptographic verifier and enforce canonical encoding for nullifiers, commitments, and anchors. The pallet will stop accepting proofs that do not bind to the value balance.

We will update the recursive/epoch proof pipeline to parse the updated transaction proof layout and public inputs. This includes updating `circuits/epoch` data extraction and updating `.agent/RECURSIVE_PROOFS_EXECPLAN.md` so it remains accurate.

We will change settlement proof handling to fail closed first, then introduce a new settlement circuit that proves batch commitments and nullifier uniqueness. The pallet will only accept proofs verified by the new circuit.

Finally, we will harden the PoW import path by computing the correct pre-hash and restoring inherent checks in production. We will remove the PQ identity all-zero fallback so nodes fail fast if key generation fails. Documentation in `DESIGN.md`, `METHODS.md`, and relevant docs under `docs/` will be updated to reflect actual behavior.

## Concrete Steps

Run all commands from `/Users/pldd/Documents/Reflexivity/synthetic-hegemonic-currency`.

1) Ensure the toolchains and node build are ready (required on fresh clones).

    make setup
    make node

2) Create a no_std transaction-core crate and move shared logic.

    mkdir -p circuits/transaction-core/src
    # Move or copy: constants.rs, hashing.rs, stark_air.rs, and public input encoding.
    # Update Cargo.toml to depend on transaction-core from circuits/transaction and pallets/shielded-pool.

3) Align runtime limits to circuit capacity.

    # Edit runtime/src/lib.rs to set MaxNullifiersPerTx = 2 and MaxCommitmentsPerTx = 2.

4) Implement full transaction constraints in the AIR and update prover and witness.

    # Edit circuits/transaction-core/src/stark_air.rs to add nullifier, Merkle, commitment, balance, and range constraints.
    # Edit circuits/transaction/src/stark_prover.rs to populate the new trace layout.
    # Add tamper-reject tests under circuits/transaction/tests.

5) Replace the pallet verifier and enforce canonical encoding.

    # Edit pallets/shielded-pool/src/verifier.rs to call the shared verifier.
    # Edit pallets/shielded-pool/src/lib.rs to reject non-canonical nullifiers, commitments, and anchors.

6) Update recursive/epoch proof pipeline to new public inputs.

    # Edit circuits/epoch to parse new proof layout and public inputs.
    # Update .agent/RECURSIVE_PROOFS_EXECPLAN.md with the new assumptions.

7) Implement settlement proof verification.

    # First: fail closed if no real verifier is wired.
    # Then: create circuits/settlement with an AIR and verifier, and wire it into pallets/settlement.

8) Harden PoW import and PQ identity.

    # Edit node/src/substrate/block_import.rs to compute pre-hash correctly.
    # Edit node/src/substrate/service.rs to restore inherent checks in production and remove the all-zero seed fallback.

## Validation and Acceptance

Transaction circuit verification:

    cargo test -p transaction-circuit

Expect all tests to pass, and new tamper-reject tests to fail before the change and pass after.

Shielded pool verifier:

    cargo test -p pallet-shielded-pool

Expect canonical-encoding rejection tests to pass and invalid proofs to be rejected.

Recursive/epoch proof pipeline:

    cargo test -p epoch-circuit

Expect recursive proof tests to pass after updating proof extraction.

Settlement:

    cargo test -p pallet-settlement

Expect invalid proofs to be rejected and valid proofs to pass only after the new circuit is wired.

PoW import behavior:

    HEGEMON_MINE=1 ./target/release/hegemon-node --dev --tmp

Expect future-dated blocks to be rejected and timestamps to be enforced during import.

## Idempotence and Recovery

All steps are safe to re-run. If a build fails after refactoring crates, check Cargo.toml dependencies and feature flags, then re-run `cargo check -p transaction-circuit`. If Winterfell panics due to constraint degree mismatch, update the `TransitionConstraintDegree` descriptors and re-run only the failing tests. Do not purge the chain; use `--tmp` or new `--base-path` values for testing.

## Artifacts and Notes

Expected test failure before hardening (example):

    test shielded_transfer_rejects_noncanonical_nullifier ... FAILED

Expected success after hardening (example):

    test shielded_transfer_rejects_noncanonical_nullifier ... ok

Expected node log when rejecting a future-dated block (example):

    WARN consensus: Block timestamp beyond allowed skew; rejecting header

## Interfaces and Dependencies

The shared transaction core must expose the following items:

- `transaction_core::constants::{MAX_INPUTS, MAX_OUTPUTS, CIRCUIT_MERKLE_DEPTH}`
- `transaction_core::hashing::{note_commitment, nullifier, merkle_node, felt_to_bytes32}`
- `transaction_core::stark_air::{TransactionAirStark, TransactionPublicInputsStark}`
- `transaction_core::stark_verifier::verify_transaction_proof_bytes`

The pallet verifier must use `transaction_core::stark_verifier::verify_transaction_proof_bytes` and fail if public inputs are non-canonical. Runtime limits in `runtime/src/lib.rs` must match `MAX_INPUTS/MAX_OUTPUTS` from transaction-core. Recursive proof extraction in `circuits/epoch` must read the new public inputs and proof layout. Settlement verification must route through a concrete verifier in `circuits/settlement` that checks commitments and nullifiers, and the pallet must treat verification failure as `ProofInvalid`.

Revision note: This ExecPlan was created to harden proof verification and consensus integrity without purging the chain, and to keep recursive proof aggregation aligned with the updated transaction proof shape.

Revision note (2025-12-19): Updated progress and decisions for recursive proof hash binding, settlement fail-closed verifier, PoW import hardening, and PQ identity fail-fast behavior; aligned follow-on documentation requirements.

Revision note (2025-12-19T03:55Z): Updated progress, discoveries, and decisions after fixing transaction AIR degree mismatches with sentinel rows/masks and rerunning transaction/settlement tests.

Revision note (2025-12-19T04:02Z): Logged pallet-shielded-pool and epoch-circuit validation runs; narrowed remaining work to documentation updates.

Revision note (2025-12-19T04:07Z): Completed remaining documentation updates and marked the ExecPlan complete with an outcomes summary.
