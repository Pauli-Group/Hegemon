use crate::error::ProofError;
mod v5;
use crate::backend_interface::{
    Challenge, CommitmentBlockProver, Compress, Config, DIGEST_ELEMS, FRI_POW_BITS, Hash,
    POSEIDON2_RATE, TransactionAirP3, TransactionProof, TransactionProofP3,
    TransactionPublicInputsP3, Val, config_with_fri, default_build_tx_fri_profile,
    felts_to_bytes48, transaction_verifier_inputs, verify_transaction_proof_p3,
};
use blake2::Blake2bVar;
use blake2::digest::{Update as BlakeUpdate, VariableOutput};
use crypto::hashes::blake3_384;
use p3_batch_stark::{BatchProof, CommonData, verify_batch};
use p3_circuit::CircuitBuilder;
use p3_circuit_prover::TablePacking;
use p3_circuit_prover::common::{CircuitTableAir, get_airs_and_degrees_with_prep};
use p3_field::{BasedVectorSpace, PrimeCharacteristicRing, PrimeField64};
use p3_recursion::pcs::fri::{FriVerifierParams, HashTargets, InputProofTargets, RecValMmcs};
use p3_recursion::pcs::{FriProofTargets, RecExtensionValMmcs, Witness};
use p3_recursion::public_inputs::StarkVerifierInputsBuilder;
use p3_recursion::verify_circuit;
use p3_uni_stark::{get_log_num_quotient_chunks, verify as verify_stark};
use parking_lot::{Condvar, Mutex};
use serde::{Deserialize, Serialize};
use std::collections::{HashMap, HashSet};
use std::sync::{Arc, OnceLock};
use std::time::Instant;
use zstd::stream::{decode_all, encode_all};

type InnerFri = FriProofTargets<
    Val,
    Challenge,
    RecExtensionValMmcs<
        Val,
        Challenge,
        DIGEST_ELEMS,
        RecValMmcs<Val, DIGEST_ELEMS, Hash, Compress>,
    >,
    InputProofTargets<Val, Challenge, RecValMmcs<Val, DIGEST_ELEMS, Hash, Compress>>,
    Witness<Val>,
>;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
struct ProofShape {
    degree_bits: usize,
    commit_phase_len: usize,
    final_poly_len: usize,
    query_count: usize,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
struct AggregationVerifierKey {
    tx_count: usize,
    pub_inputs_len: usize,
    log_blowup: usize,
    shape: ProofShape,
}

struct AggregationVerifierCacheEntry {
    outer_config: Config,
    airs: Vec<CircuitTableAir<Config, 2>>,
    common: CommonData<Config>,
    public_table_indices: Vec<usize>,
}

#[derive(Default)]
struct AggregationVerifierCacheState {
    entries: HashMap<AggregationVerifierKey, Arc<AggregationVerifierCacheEntry>>,
    in_progress: HashSet<AggregationVerifierKey>,
}

struct AggregationVerifierCache {
    state: Mutex<AggregationVerifierCacheState>,
    condvar: Condvar,
}

fn decode_postcard_exact<'a, T>(bytes: &'a [u8], label: &str) -> Result<T, String>
where
    T: Deserialize<'a>,
{
    let (value, remaining) =
        postcard::take_from_bytes(bytes).map_err(|err| format!("{label} decode failed: {err}"))?;
    if !remaining.is_empty() {
        return Err(format!(
            "{label} decode left {} trailing bytes",
            remaining.len()
        ));
    }
    Ok(value)
}

impl Default for AggregationVerifierCache {
    fn default() -> Self {
        Self {
            state: Mutex::new(AggregationVerifierCacheState::default()),
            condvar: Condvar::new(),
        }
    }
}

static AGGREGATION_VERIFIER_CACHE: OnceLock<AggregationVerifierCache> = OnceLock::new();

const AGGREGATION_PROOF_MAGIC: [u8; 4] = *b"HGA0";
const AGGREGATION_PROOF_VERSION: u8 = 1;
const AGGREGATION_PROOF_HEADER_LEN: usize = 4 + 1 + 4;
const AGGREGATION_PROOF_ZSTD_LEVEL: i32 = 3;
const MAX_AGGREGATION_PROOF_UNCOMPRESSED_LEN: usize = 64 * 1024 * 1024;
pub const AGGREGATION_PROOF_FORMAT_VERSION_V4: u8 = 4;
const AGGREGATION_PUBLIC_VALUES_ENCODING_V1: u8 = 1;
const MAX_AGGREGATION_SLOT_PADDING_FACTOR: usize = 16;
const BINDING_HASH_DOMAIN: &[u8] = b"binding-hash-v3";
const STATEMENT_HASH_DOMAIN: &[u8] = b"tx-statement-v1";
const DEFAULT_OUTER_BATCH_LOG_BLOWUP: usize = 2;
const DEFAULT_OUTER_BATCH_NUM_QUERIES: usize = 2;

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
struct AggregationProofV4Payload {
    version: u8,
    proof_format: u8,
    tree_arity: u16,
    tree_levels: u16,
    root_level: u16,
    shape_id: [u8; 32],
    // Number of recursion slots carried by this payload (can be padded above block tx count).
    tx_count: u32,
    tx_statements_commitment: Vec<u8>,
    public_values_encoding: u8,
    inner_public_inputs_len: u32,
    representative_proof: Vec<u8>,
    packed_public_values: Vec<u64>,
    outer_proof: Vec<u8>,
}

fn aggregation_verifier_cache() -> &'static AggregationVerifierCache {
    AGGREGATION_VERIFIER_CACHE.get_or_init(AggregationVerifierCache::default)
}

fn outer_batch_log_blowup() -> usize {
    std::env::var("HEGEMON_AGG_OUTER_LOG_BLOWUP")
        .ok()
        .and_then(|raw| raw.parse::<usize>().ok())
        .unwrap_or(DEFAULT_OUTER_BATCH_LOG_BLOWUP)
        .max(1)
}

fn outer_batch_num_queries() -> usize {
    std::env::var("HEGEMON_AGG_OUTER_NUM_QUERIES")
        .ok()
        .and_then(|raw| raw.parse::<usize>().ok())
        .unwrap_or(DEFAULT_OUTER_BATCH_NUM_QUERIES)
        .max(1)
}

fn outer_batch_config() -> Config {
    config_with_fri(outer_batch_log_blowup(), outer_batch_num_queries()).config
}

fn legacy_v4_enabled() -> bool {
    false
}

struct AggregationCacheResult {
    entry: Arc<AggregationVerifierCacheEntry>,
    cache_hit: bool,
    cache_build_ms: u128,
}

#[derive(Clone, Copy, Debug)]
pub struct AggregationCacheWarmup {
    pub cache_hit: bool,
    pub cache_build_ms: u128,
}

#[derive(Clone, Copy, Debug)]
pub struct AggregationVerifyMetrics {
    pub cache_hit: bool,
    pub cache_build_ms: u128,
    pub verify_batch_ms: u128,
    pub total_ms: u128,
}

fn build_aggregation_verifier_cache_entry(
    key: AggregationVerifierKey,
    representative_proof: &TransactionProofP3,
) -> Result<AggregationVerifierCacheEntry, ProofError> {
    let inner_config = config_with_fri(key.log_blowup, key.shape.query_count);
    let commit_pow_bits = 0;
    let query_pow_bits = FRI_POW_BITS;

    let final_poly_len = key.shape.final_poly_len;
    if final_poly_len == 0 || !final_poly_len.is_power_of_two() {
        return Err(ProofError::AggregationProofInputsMismatch(
            "transaction proof final polynomial length invalid".to_string(),
        ));
    }
    let log_final_poly_len = final_poly_len.ilog2() as usize;
    let _log_height_max = log_final_poly_len + key.log_blowup;
    let fri_verifier_params = FriVerifierParams {
        log_blowup: key.log_blowup,
        log_final_poly_len,
        commit_pow_bits,
        query_pow_bits,
    };

    let mut circuit_builder = CircuitBuilder::<Challenge>::new();
    for _ in 0..key.tx_count {
        let inputs = StarkVerifierInputsBuilder::<Config, HashTargets<Val, DIGEST_ELEMS>, InnerFri>::allocate(
            &mut circuit_builder,
            representative_proof,
            None,
            key.pub_inputs_len,
        );
        verify_circuit::<
            TransactionAirP3,
            Config,
            HashTargets<Val, DIGEST_ELEMS>,
            InputProofTargets<Val, Challenge, RecValMmcs<Val, DIGEST_ELEMS, Hash, Compress>>,
            InnerFri,
            POSEIDON2_RATE,
        >(
            &inner_config.config,
            &TransactionAirP3,
            &mut circuit_builder,
            &inputs.proof_targets,
            &inputs.air_public_targets,
            &None,
            &fri_verifier_params,
        )
        .map_err(|err| {
            ProofError::AggregationProofVerification(format!(
                "recursion circuit build failed: {err:?}"
            ))
        })?;
    }

    let circuit = circuit_builder.build().map_err(|err| {
        ProofError::AggregationProofVerification(format!(
            "aggregation circuit build failed: {err:?}"
        ))
    })?;

    let table_packing = TablePacking::new(4, 4, 1);
    let (airs_degrees, _) = get_airs_and_degrees_with_prep::<Config, _, 2>(
        &circuit,
        table_packing,
        None,
    )
    .map_err(|err| {
        ProofError::AggregationProofVerification(format!("aggregation AIR setup failed: {err:?}"))
    })?;
    let (mut airs, degrees): (Vec<_>, Vec<_>) = airs_degrees.into_iter().unzip();

    let outer_config = outer_batch_config();
    let common = CommonData::from_airs_and_degrees(&outer_config, &mut airs, &degrees);

    let public_table_indices = airs
        .iter()
        .enumerate()
        .filter_map(|(idx, air)| matches!(air, CircuitTableAir::Public(_)).then_some(idx))
        .collect::<Vec<_>>();

    if public_table_indices.is_empty() {
        return Err(ProofError::AggregationProofVerification(
            "aggregation circuit missing public table".to_string(),
        ));
    }

    Ok(AggregationVerifierCacheEntry {
        outer_config,
        airs,
        common,
        public_table_indices,
    })
}

fn transaction_log_blowup_for_public_inputs(pub_inputs_len: usize) -> usize {
    let log_chunks = get_log_num_quotient_chunks::<Val, _>(&TransactionAirP3, 0, pub_inputs_len, 0);
    default_build_tx_fri_profile()
        .log_blowup_usize()
        .max(log_chunks)
}

fn resolve_log_blowup(
    proof: &TransactionProofP3,
    pub_inputs: &[Val],
    query_count: usize,
) -> Result<usize, String> {
    if query_count == 0 {
        return Err("proof has zero FRI queries".to_string());
    }

    let inferred = infer_log_blowup_from_proof_shape(proof);
    let mut candidates = Vec::new();
    let mut push_unique = |value: usize| {
        if !candidates.contains(&value) {
            candidates.push(value);
        }
    };

    if let Some(log_blowup) = inferred {
        push_unique(log_blowup);
        for delta in 1..=2 {
            push_unique(log_blowup.saturating_sub(delta));
            push_unique(log_blowup.saturating_add(delta));
        }
    }
    push_unique(default_build_tx_fri_profile().log_blowup_usize());
    for fallback in 0..=8 {
        push_unique(fallback);
    }

    for log_blowup in candidates.iter().copied() {
        let config = config_with_fri(log_blowup, query_count);
        if verify_stark(&config.config, &TransactionAirP3, proof, pub_inputs).is_ok() {
            return Ok(log_blowup);
        }
    }

    Err(format!(
        "unable to resolve FRI log_blowup (inferred={inferred:?}, attempted={candidates:?})"
    ))
}

fn infer_log_blowup_from_proof_shape(proof: &TransactionProofP3) -> Option<usize> {
    let final_poly_len = proof.opening_proof.final_poly.len();
    if final_poly_len == 0 || !final_poly_len.is_power_of_two() {
        return None;
    }
    let log_final_poly_len = final_poly_len.ilog2() as usize;
    let commit_phase_len = proof.opening_proof.commit_phase_commits.len();
    let baseline = commit_phase_len + log_final_poly_len;

    let mut observed_log_max_height: Option<usize> = None;
    for query_proof in proof.opening_proof.query_proofs.iter() {
        let query_max = query_proof
            .input_proof
            .iter()
            .map(|batch| batch.opening_proof.len())
            .max()?;
        if query_max < baseline {
            return None;
        }
        match observed_log_max_height {
            Some(expected) if expected != query_max => return None,
            Some(_) => {}
            None => observed_log_max_height = Some(query_max),
        }
    }

    observed_log_max_height?.checked_sub(baseline)
}

fn tree_levels_for_tx_count(tx_count: usize, arity: u16) -> u16 {
    if tx_count <= 1 {
        return 1;
    }
    let mut levels = 1u16;
    let mut width = tx_count;
    let radix = arity.max(2) as usize;
    while width > 1 {
        width = width.div_ceil(radix);
        levels = levels.saturating_add(1);
    }
    levels
}

fn aggregation_shape_id(
    tx_count: usize,
    pub_inputs_len: usize,
    log_blowup: usize,
    shape: ProofShape,
) -> [u8; 32] {
    let mut bytes = Vec::with_capacity(8 * 8);
    bytes.extend_from_slice(&(AGGREGATION_PROOF_FORMAT_VERSION_V4 as u64).to_le_bytes());
    bytes.extend_from_slice(&(tx_count as u64).to_le_bytes());
    bytes.extend_from_slice(&(pub_inputs_len as u64).to_le_bytes());
    bytes.extend_from_slice(&(log_blowup as u64).to_le_bytes());
    bytes.extend_from_slice(&(shape.degree_bits as u64).to_le_bytes());
    bytes.extend_from_slice(&(shape.commit_phase_len as u64).to_le_bytes());
    bytes.extend_from_slice(&(shape.final_poly_len as u64).to_le_bytes());
    bytes.extend_from_slice(&(shape.query_count as u64).to_le_bytes());
    blake2_256(&bytes)
}

fn validate_payload_header(
    payload: &AggregationProofV4Payload,
    tx_count: usize,
    expected_statement_commitment: &[u8; 48],
) -> Result<usize, ProofError> {
    if payload.version != AGGREGATION_PROOF_FORMAT_VERSION_V4 {
        return Err(ProofError::AggregationProofV4Decode(format!(
            "unsupported aggregation proof payload version {}",
            payload.version
        )));
    }
    if payload.proof_format != AGGREGATION_PROOF_FORMAT_VERSION_V4 {
        return Err(ProofError::AggregationProofV4Decode(format!(
            "unsupported aggregation proof format {}",
            payload.proof_format
        )));
    }
    if payload.tree_arity < 2 {
        return Err(ProofError::AggregationProofV4Decode(
            "tree_arity must be at least 2".to_string(),
        ));
    }
    if payload.tree_levels == 0 {
        return Err(ProofError::AggregationProofV4Decode(
            "tree_levels must be non-zero".to_string(),
        ));
    }
    let slot_tx_count = payload.tx_count as usize;
    if slot_tx_count == 0 {
        return Err(ProofError::AggregationProofV4Decode(
            "tx_count must be greater than zero".to_string(),
        ));
    }
    if slot_tx_count < tx_count {
        return Err(ProofError::AggregationProofV4Binding(format!(
            "slot tx_count {} cannot be lower than block tx_count {}",
            slot_tx_count, tx_count
        )));
    }
    let max_slot_tx_count = tx_count
        .saturating_mul(MAX_AGGREGATION_SLOT_PADDING_FACTOR)
        .max(tx_count);
    if slot_tx_count > max_slot_tx_count {
        return Err(ProofError::AggregationProofV4Binding(format!(
            "slot tx_count {} exceeds max allowed {} for block tx_count {}",
            slot_tx_count, max_slot_tx_count, tx_count
        )));
    }

    let expected_levels = tree_levels_for_tx_count(slot_tx_count, payload.tree_arity);
    if payload.tree_levels != expected_levels {
        return Err(ProofError::AggregationProofV4Binding(format!(
            "tree_levels mismatch (payload {}, expected {})",
            payload.tree_levels, expected_levels
        )));
    }
    if payload.root_level >= payload.tree_levels {
        return Err(ProofError::AggregationProofV4Decode(format!(
            "root_level {} must be less than tree_levels {}",
            payload.root_level, payload.tree_levels
        )));
    }
    if payload.tx_statements_commitment.len() != 48 {
        return Err(ProofError::AggregationProofV4Decode(
            "tx_statements_commitment length invalid".to_string(),
        ));
    }
    if payload.tx_statements_commitment.as_slice() != expected_statement_commitment.as_slice() {
        return Err(ProofError::AggregationProofV4Binding(
            "tx_statements_commitment mismatch".to_string(),
        ));
    }
    Ok(slot_tx_count)
}

fn get_or_build_aggregation_verifier_cache_entry(
    key: AggregationVerifierKey,
    representative_proof: &TransactionProofP3,
) -> Result<AggregationCacheResult, ProofError> {
    let cache = aggregation_verifier_cache();
    loop {
        let mut state = cache.state.lock();
        if let Some(entry) = state.entries.get(&key).cloned() {
            return Ok(AggregationCacheResult {
                entry,
                cache_hit: true,
                cache_build_ms: 0,
            });
        }

        if state.in_progress.insert(key) {
            drop(state);

            let start_build = Instant::now();
            let built =
                build_aggregation_verifier_cache_entry(key, representative_proof).map(Arc::new);
            let build_ms = start_build.elapsed().as_millis();

            let mut state = cache.state.lock();
            state.in_progress.remove(&key);
            match built {
                Ok(built_entry) => {
                    let entry = state
                        .entries
                        .entry(key)
                        .or_insert_with(|| built_entry.clone())
                        .clone();
                    cache.condvar.notify_all();
                    return Ok(AggregationCacheResult {
                        entry,
                        cache_hit: false,
                        cache_build_ms: build_ms,
                    });
                }
                Err(err) => {
                    cache.condvar.notify_all();
                    return Err(err);
                }
            }
        }

        while state.in_progress.contains(&key) {
            cache.condvar.wait(&mut state);
        }
    }
}

pub fn encode_aggregation_proof_bytes(raw_bytes: Vec<u8>) -> Vec<u8> {
    if raw_bytes.is_empty() {
        return raw_bytes;
    }
    let compressed = match encode_all(raw_bytes.as_slice(), AGGREGATION_PROOF_ZSTD_LEVEL) {
        Ok(bytes) => bytes,
        Err(_) => return raw_bytes,
    };
    if compressed.is_empty() {
        return raw_bytes;
    }

    let mut encoded = Vec::with_capacity(AGGREGATION_PROOF_HEADER_LEN + compressed.len());
    encoded.extend_from_slice(&AGGREGATION_PROOF_MAGIC);
    encoded.push(AGGREGATION_PROOF_VERSION);
    encoded.extend_from_slice(&(raw_bytes.len() as u32).to_le_bytes());
    encoded.extend_from_slice(&compressed);

    if encoded.len() < raw_bytes.len() {
        encoded
    } else {
        raw_bytes
    }
}

pub fn aggregation_proof_uncompressed_len(bytes: &[u8]) -> usize {
    if bytes.len() < AGGREGATION_PROOF_HEADER_LEN {
        return bytes.len();
    }
    if &bytes[..4] != AGGREGATION_PROOF_MAGIC.as_slice() {
        return bytes.len();
    }
    if bytes[4] != AGGREGATION_PROOF_VERSION {
        return bytes.len();
    }
    let mut len_bytes = [0u8; 4];
    len_bytes.copy_from_slice(&bytes[5..9]);
    let length = u32::from_le_bytes(len_bytes) as usize;
    if length == 0 || length > MAX_AGGREGATION_PROOF_UNCOMPRESSED_LEN {
        return bytes.len();
    }
    length
}

pub fn decode_aggregation_proof_bytes(bytes: &[u8]) -> Result<Vec<u8>, ProofError> {
    if bytes.len() < AGGREGATION_PROOF_HEADER_LEN {
        return Ok(bytes.to_vec());
    }
    if &bytes[..4] != AGGREGATION_PROOF_MAGIC.as_slice() {
        return Ok(bytes.to_vec());
    }
    if bytes[4] != AGGREGATION_PROOF_VERSION {
        return Err(ProofError::AggregationProofInputsMismatch(
            "aggregation proof compression version mismatch".to_string(),
        ));
    }
    let mut len_bytes = [0u8; 4];
    len_bytes.copy_from_slice(&bytes[5..9]);
    let expected_len = u32::from_le_bytes(len_bytes) as usize;
    if expected_len == 0 || expected_len > MAX_AGGREGATION_PROOF_UNCOMPRESSED_LEN {
        return Err(ProofError::AggregationProofInputsMismatch(
            "aggregation proof uncompressed length invalid".to_string(),
        ));
    }
    let compressed = &bytes[AGGREGATION_PROOF_HEADER_LEN..];
    if compressed.is_empty() {
        return Err(ProofError::AggregationProofInputsMismatch(
            "aggregation proof compressed payload missing".to_string(),
        ));
    }
    let decoded = decode_all(compressed).map_err(|err| {
        ProofError::AggregationProofInputsMismatch(format!(
            "aggregation proof decompression failed: {err}"
        ))
    })?;
    if decoded.len() != expected_len {
        return Err(ProofError::AggregationProofInputsMismatch(
            "aggregation proof decompressed length mismatch".to_string(),
        ));
    }
    Ok(decoded)
}

fn decode_signed_i128_from_parts(sign: Val, magnitude: Val) -> Result<i128, ProofError> {
    let sign_bit = sign.as_canonical_u64();
    if sign_bit > 1 {
        return Err(ProofError::AggregationProofV4Binding(
            "invalid value_balance_sign in aggregated statement".to_string(),
        ));
    }
    let magnitude_i128 = magnitude.as_canonical_u64() as i128;
    Ok(if sign_bit == 1 {
        -magnitude_i128
    } else {
        magnitude_i128
    })
}

fn active_prefix_len(flags: &[Val], label: &str) -> Result<usize, ProofError> {
    let mut seen_zero = false;
    let mut count = 0usize;
    for (idx, flag) in flags.iter().enumerate() {
        let bit = flag.as_canonical_u64();
        if bit > 1 {
            return Err(ProofError::AggregationProofV4Binding(format!(
                "{label}[{idx}] is not boolean"
            )));
        }
        if bit == 1 {
            if seen_zero {
                return Err(ProofError::AggregationProofV4Binding(format!(
                    "{label} contains non-prefix active slot at index {idx}"
                )));
            }
            count += 1;
        } else {
            seen_zero = true;
        }
    }
    Ok(count)
}

fn ensure_zeroed_suffix(
    values: &[[Val; 6]],
    active_len: usize,
    label: &str,
) -> Result<(), ProofError> {
    for (idx, value) in values.iter().enumerate().skip(active_len) {
        if felts_to_bytes48(value) != [0u8; 48] {
            return Err(ProofError::AggregationProofV4Binding(format!(
                "{label}[{idx}] must be zero when inactive"
            )));
        }
    }
    Ok(())
}

fn binding_hash_from_public_inputs(
    public: &TransactionPublicInputsP3,
) -> Result<[u8; 64], ProofError> {
    let input_count = active_prefix_len(&public.input_flags, "input_flags")?;
    let output_count = active_prefix_len(&public.output_flags, "output_flags")?;
    ensure_zeroed_suffix(&public.nullifiers, input_count, "nullifiers")?;
    ensure_zeroed_suffix(&public.commitments, output_count, "commitments")?;
    ensure_zeroed_suffix(&public.ciphertext_hashes, output_count, "ciphertext_hashes")?;

    let mut message = Vec::with_capacity(
        48 + 12
            + input_count * 48
            + output_count * 48
            + output_count * 48
            + 24
            + public.balance_slot_assets.len() * 8
            + 1
            + 8
            + 48
            + 48
            + 48
            + 16
            + 4,
    );
    message.extend_from_slice(&felts_to_bytes48(&public.merkle_root));
    extend_binding_len(&mut message, input_count);
    for nf in public.nullifiers.iter().take(input_count) {
        message.extend_from_slice(&felts_to_bytes48(nf));
    }
    extend_binding_len(&mut message, output_count);
    for cm in public.commitments.iter().take(output_count) {
        message.extend_from_slice(&felts_to_bytes48(cm));
    }
    extend_binding_len(&mut message, output_count);
    for ct in public.ciphertext_hashes.iter().take(output_count) {
        message.extend_from_slice(&felts_to_bytes48(ct));
    }
    message.extend_from_slice(&public.fee.as_canonical_u64().to_le_bytes());
    let value_balance =
        decode_signed_i128_from_parts(public.value_balance_sign, public.value_balance_magnitude)?;
    message.extend_from_slice(&value_balance.to_le_bytes());
    for asset_id in public.balance_slot_assets {
        message.extend_from_slice(&asset_id.as_canonical_u64().to_le_bytes());
    }

    let stablecoin_enabled =
        canonical_u8_public_input(public.stablecoin_enabled, "stablecoin_enabled")?;
    if stablecoin_enabled > 1 {
        return Err(ProofError::AggregationProofV4Binding(
            "stablecoin_enabled is not boolean".to_string(),
        ));
    }
    let stablecoin_asset = public.stablecoin_asset.as_canonical_u64();
    let stablecoin_policy_version = canonical_u32_public_input(
        public.stablecoin_policy_version,
        "stablecoin_policy_version",
    )?;
    let stablecoin_issuance_sign =
        canonical_u8_public_input(public.stablecoin_issuance_sign, "stablecoin_issuance_sign")?;
    let stablecoin_issuance_magnitude = public.stablecoin_issuance_magnitude.as_canonical_u64();
    let stablecoin_issuance = decode_signed_i128_from_parts(
        public.stablecoin_issuance_sign,
        public.stablecoin_issuance_magnitude,
    )?;
    let stablecoin_policy_hash = felts_to_bytes48(&public.stablecoin_policy_hash);
    let stablecoin_oracle_commitment = felts_to_bytes48(&public.stablecoin_oracle_commitment);
    let stablecoin_attestation_commitment =
        felts_to_bytes48(&public.stablecoin_attestation_commitment);
    if stablecoin_enabled == 0
        && (stablecoin_asset != 0
            || stablecoin_policy_version != 0
            || stablecoin_issuance_sign != 0
            || stablecoin_issuance_magnitude != 0
            || stablecoin_policy_hash != [0u8; 48]
            || stablecoin_oracle_commitment != [0u8; 48]
            || stablecoin_attestation_commitment != [0u8; 48])
    {
        return Err(ProofError::AggregationProofV4Binding(
            "disabled stablecoin public fields must be zero".to_string(),
        ));
    }
    message.push(stablecoin_enabled);
    message.extend_from_slice(&stablecoin_asset.to_le_bytes());
    message.extend_from_slice(&stablecoin_policy_hash);
    message.extend_from_slice(&stablecoin_oracle_commitment);
    message.extend_from_slice(&stablecoin_attestation_commitment);
    message.extend_from_slice(&stablecoin_issuance.to_le_bytes());
    message.extend_from_slice(&stablecoin_policy_version.to_le_bytes());

    let mut msg0 = Vec::with_capacity(BINDING_HASH_DOMAIN.len() + 1 + message.len());
    msg0.extend_from_slice(BINDING_HASH_DOMAIN);
    msg0.push(0);
    msg0.extend_from_slice(&message);
    let hash0 = blake2_256(&msg0);

    let mut msg1 = Vec::with_capacity(BINDING_HASH_DOMAIN.len() + 1 + message.len());
    msg1.extend_from_slice(BINDING_HASH_DOMAIN);
    msg1.push(1);
    msg1.extend_from_slice(&message);
    let hash1 = blake2_256(&msg1);

    let mut out = [0u8; 64];
    out[..32].copy_from_slice(&hash0);
    out[32..].copy_from_slice(&hash1);
    Ok(out)
}

fn extend_binding_len(message: &mut Vec<u8>, len: usize) {
    let len = u32::try_from(len).expect("aggregation binding vector length exceeds u32");
    message.extend_from_slice(&len.to_le_bytes());
}

fn canonical_u8_public_input(value: Val, label: &str) -> Result<u8, ProofError> {
    let raw = value.as_canonical_u64();
    u8::try_from(raw)
        .map_err(|_| ProofError::AggregationProofV4Binding(format!("{label} does not fit in u8")))
}

fn canonical_u32_public_input(value: Val, label: &str) -> Result<u32, ProofError> {
    let raw = value.as_canonical_u64();
    u32::try_from(raw)
        .map_err(|_| ProofError::AggregationProofV4Binding(format!("{label} does not fit in u32")))
}

fn blake2_256(bytes: &[u8]) -> [u8; 32] {
    let mut hasher = Blake2bVar::new(32).expect("valid BLAKE2b output length");
    hasher.update(bytes);
    let mut out = [0u8; 32];
    hasher
        .finalize_variable(&mut out)
        .expect("fixed output buffer has requested length");
    out
}

fn statement_hash_from_binding_hash(binding_hash: &[u8; 64]) -> [u8; 48] {
    let mut message = Vec::with_capacity(STATEMENT_HASH_DOMAIN.len() + binding_hash.len());
    message.extend_from_slice(STATEMENT_HASH_DOMAIN);
    message.extend_from_slice(binding_hash);
    blake3_384(&message)
}

fn derive_statement_commitment_from_packed_public_values(
    packed_public_values: &[u64],
    slot_tx_count: usize,
    active_tx_count: usize,
    pub_inputs_len: usize,
) -> Result<[u8; 48], ProofError> {
    let tx_public_inputs = decode_public_inputs_from_packed_public_values(
        packed_public_values,
        slot_tx_count,
        pub_inputs_len,
    )?;
    if tx_public_inputs.len() < active_tx_count {
        return Err(ProofError::AggregationProofV4Binding(format!(
            "decoded slot public inputs {} shorter than active tx_count {}",
            tx_public_inputs.len(),
            active_tx_count
        )));
    }
    statement_commitment_from_public_inputs(&tx_public_inputs[..active_tx_count])
}

fn statement_commitment_from_public_inputs(
    tx_public_inputs: &[TransactionPublicInputsP3],
) -> Result<[u8; 48], ProofError> {
    let mut statement_hashes = Vec::with_capacity(tx_public_inputs.len());
    for tx_public in tx_public_inputs {
        let binding_hash = binding_hash_from_public_inputs(tx_public)?;
        statement_hashes.push(statement_hash_from_binding_hash(&binding_hash));
    }

    CommitmentBlockProver::commitment_from_statement_hashes(&statement_hashes).map_err(|err| {
        ProofError::AggregationProofV4Binding(format!(
            "statement commitment derivation failed: {err}"
        ))
    })
}

fn decode_public_inputs_from_packed_public_values(
    packed_public_values: &[u64],
    slot_tx_count: usize,
    pub_inputs_len: usize,
) -> Result<Vec<TransactionPublicInputsP3>, ProofError> {
    let ext_degree = <Challenge as BasedVectorSpace<Val>>::DIMENSION;
    if !packed_public_values.len().is_multiple_of(ext_degree) {
        return Err(ProofError::AggregationProofV4Decode(
            "packed_public_values length is not aligned to extension degree".to_string(),
        ));
    }

    if slot_tx_count == 0 {
        return Err(ProofError::AggregationProofV4Decode(
            "tx_count must be greater than zero".to_string(),
        ));
    }

    let total_extension_values = packed_public_values.len() / ext_degree;
    if !total_extension_values.is_multiple_of(slot_tx_count) {
        return Err(ProofError::AggregationProofV4Decode(
            "packed_public_values length does not align with slot tx_count".to_string(),
        ));
    }
    let per_tx_extension_values = total_extension_values / slot_tx_count;
    if per_tx_extension_values < pub_inputs_len {
        return Err(ProofError::AggregationProofV4Decode(
            "packed_public_values missing transaction public inputs".to_string(),
        ));
    }

    let per_tx_word_stride = per_tx_extension_values * ext_degree;
    let public_values_word_len = pub_inputs_len * ext_degree;

    let mut tx_public_inputs = Vec::with_capacity(slot_tx_count);
    for tx_index in 0..slot_tx_count {
        let tx_offset_words = tx_index * per_tx_word_stride;
        let tx_public_words =
            &packed_public_values[tx_offset_words..tx_offset_words + public_values_word_len];

        let mut tx_public_values = Vec::with_capacity(pub_inputs_len);
        for idx in 0..pub_inputs_len {
            let coeff_offset = idx * ext_degree;
            let base_coeff = tx_public_words[coeff_offset];
            for limb in 1..ext_degree {
                if tx_public_words[coeff_offset + limb] != 0 {
                    return Err(ProofError::AggregationProofV4Binding(format!(
                        "tx {tx_index} public input {idx} is not base-lifted"
                    )));
                }
            }
            tx_public_values.push(Val::from_u64(base_coeff));
        }

        let tx_public =
            TransactionPublicInputsP3::try_from_slice(&tx_public_values).map_err(|err| {
                ProofError::AggregationProofV4Binding(format!(
                    "tx {tx_index} public input decode failed: {err}"
                ))
            })?;
        tx_public_inputs.push(tx_public);
    }
    Ok(tx_public_inputs)
}

pub fn warm_aggregation_cache(
    representative_proof: &TransactionProof,
    tx_count: usize,
) -> Result<AggregationCacheWarmup, ProofError> {
    if tx_count == 0 {
        return Err(ProofError::AggregationProofEmptyBlock);
    }
    if representative_proof.stark_proof.is_empty() {
        return Err(ProofError::AggregationProofInputsMismatch(
            "transaction proof missing STARK proof bytes".to_string(),
        ));
    }

    let pub_inputs = transaction_verifier_inputs(representative_proof).map_err(|err| {
        ProofError::AggregationProofInputsMismatch(format!(
            "transaction proof public inputs invalid: {err}"
        ))
    })?;
    let pub_inputs_vec = pub_inputs.to_vec();

    let inner_proof: TransactionProofP3 = decode_postcard_exact(
        &representative_proof.stark_proof,
        "transaction proof",
    )
    .map_err(|_| {
        ProofError::AggregationProofInputsMismatch("transaction proof encoding invalid".to_string())
    })?;
    let shape = ProofShape {
        degree_bits: inner_proof.degree_bits,
        commit_phase_len: inner_proof.opening_proof.commit_phase_commits.len(),
        final_poly_len: inner_proof.opening_proof.final_poly.len(),
        query_count: inner_proof.opening_proof.query_proofs.len(),
    };
    let log_blowup = transaction_log_blowup_for_public_inputs(pub_inputs_vec.len());
    let cache_key = AggregationVerifierKey {
        tx_count,
        pub_inputs_len: pub_inputs_vec.len(),
        log_blowup,
        shape,
    };

    let cache_result = get_or_build_aggregation_verifier_cache_entry(cache_key, &inner_proof)?;
    Ok(AggregationCacheWarmup {
        cache_hit: cache_result.cache_hit,
        cache_build_ms: cache_result.cache_build_ms,
    })
}

pub fn warm_aggregation_cache_from_proof_bytes(
    aggregation_proof: &[u8],
    tx_count: usize,
    expected_statement_commitment: &[u8; 48],
) -> Result<AggregationCacheWarmup, ProofError> {
    if tx_count == 0 {
        return Err(ProofError::AggregationProofEmptyBlock);
    }
    if aggregation_proof.is_empty() {
        return Err(ProofError::AggregationProofInputsMismatch(
            "aggregation proof bytes empty".to_string(),
        ));
    }

    let decoded = decode_aggregation_proof_bytes(aggregation_proof)?;
    if let Ok(payload_v5) =
        decode_postcard_exact::<v5::AggregationProofV5Payload>(&decoded, "aggregation V5 payload")
        && payload_v5.version == 5
    {
        return v5::warm_aggregation_cache_from_payload(
            &payload_v5,
            tx_count,
            expected_statement_commitment,
        );
    }
    if !legacy_v4_enabled() {
        return Err(ProofError::AggregationProofV5Decode(
            "legacy V4 aggregation payloads are disabled on the fresh testnet".to_string(),
        ));
    }
    let payload: AggregationProofV4Payload =
        decode_postcard_exact(&decoded, "aggregation V4 payload").map_err(|_| {
            ProofError::AggregationProofV4Decode(
                "aggregation V4 payload encoding invalid".to_string(),
            )
        })?;

    let slot_tx_count = validate_payload_header(&payload, tx_count, expected_statement_commitment)?;
    if payload.representative_proof.is_empty() {
        return Err(ProofError::AggregationProofV4Decode(
            "representative proof missing".to_string(),
        ));
    }
    let pub_inputs_len = payload.inner_public_inputs_len as usize;
    if pub_inputs_len == 0 {
        return Err(ProofError::AggregationProofV4Decode(
            "inner_public_inputs_len must be non-zero".to_string(),
        ));
    }
    if payload.public_values_encoding != AGGREGATION_PUBLIC_VALUES_ENCODING_V1 {
        return Err(ProofError::AggregationProofV4Decode(format!(
            "unsupported packed public values encoding version {}",
            payload.public_values_encoding
        )));
    }
    let derived_statement_commitment = derive_statement_commitment_from_packed_public_values(
        &payload.packed_public_values,
        slot_tx_count,
        tx_count,
        pub_inputs_len,
    )?;
    if derived_statement_commitment != *expected_statement_commitment {
        return Err(ProofError::AggregationProofV4Binding(
            "statement commitment derived from aggregated public inputs does not match expected commitment"
                .to_string(),
        ));
    }
    if payload.outer_proof.is_empty() {
        if tx_count == 1 && slot_tx_count == 1 {
            return Ok(AggregationCacheWarmup {
                cache_hit: false,
                cache_build_ms: 0,
            });
        }
        return Err(ProofError::AggregationProofV4Decode(
            "outer aggregation proof missing".to_string(),
        ));
    }

    let representative_proof: TransactionProofP3 = decode_postcard_exact(
        &payload.representative_proof,
        "representative proof",
    )
    .map_err(|_| {
        ProofError::AggregationProofV4Decode("representative proof encoding invalid".to_string())
    })?;
    let shape = ProofShape {
        degree_bits: representative_proof.degree_bits,
        commit_phase_len: representative_proof
            .opening_proof
            .commit_phase_commits
            .len(),
        final_poly_len: representative_proof.opening_proof.final_poly.len(),
        query_count: representative_proof.opening_proof.query_proofs.len(),
    };
    let log_blowup = transaction_log_blowup_for_public_inputs(pub_inputs_len);
    let expected_shape_id = aggregation_shape_id(slot_tx_count, pub_inputs_len, log_blowup, shape);
    if payload.shape_id != expected_shape_id {
        return Err(ProofError::AggregationProofV4Binding(
            "shape_id mismatch".to_string(),
        ));
    }
    let cache_key = AggregationVerifierKey {
        tx_count: slot_tx_count,
        pub_inputs_len,
        log_blowup,
        shape,
    };
    let cache_result =
        get_or_build_aggregation_verifier_cache_entry(cache_key, &representative_proof)?;

    Ok(AggregationCacheWarmup {
        cache_hit: cache_result.cache_hit,
        cache_build_ms: cache_result.cache_build_ms,
    })
}

pub fn verify_aggregation_proof_with_metrics(
    aggregation_proof: &[u8],
    tx_count: usize,
    expected_statement_commitment: &[u8; 48],
) -> Result<AggregationVerifyMetrics, ProofError> {
    let start_total = Instant::now();

    if tx_count == 0 {
        return Err(ProofError::AggregationProofEmptyBlock);
    }
    if aggregation_proof.is_empty() {
        return Err(ProofError::AggregationProofInputsMismatch(
            "aggregation proof bytes empty".to_string(),
        ));
    }

    let decoded = decode_aggregation_proof_bytes(aggregation_proof)?;
    if let Ok(payload_v5) =
        decode_postcard_exact::<v5::AggregationProofV5Payload>(&decoded, "aggregation V5 payload")
        && payload_v5.version == 5
    {
        return v5::verify_with_metrics(&payload_v5, tx_count, expected_statement_commitment);
    }
    if !legacy_v4_enabled() {
        return Err(ProofError::AggregationProofV5Decode(
            "legacy V4 aggregation payloads are disabled on the fresh testnet".to_string(),
        ));
    }
    let payload: AggregationProofV4Payload =
        decode_postcard_exact(&decoded, "aggregation V4 payload").map_err(|_| {
            ProofError::AggregationProofV4Decode(
                "aggregation V4 payload encoding invalid".to_string(),
            )
        })?;

    let slot_tx_count = validate_payload_header(&payload, tx_count, expected_statement_commitment)?;
    if payload.representative_proof.is_empty() {
        return Err(ProofError::AggregationProofV4Decode(
            "representative proof missing".to_string(),
        ));
    }
    let pub_inputs_len = payload.inner_public_inputs_len as usize;
    if pub_inputs_len == 0 {
        return Err(ProofError::AggregationProofV4Decode(
            "inner_public_inputs_len must be non-zero".to_string(),
        ));
    }
    if payload.public_values_encoding != AGGREGATION_PUBLIC_VALUES_ENCODING_V1 {
        return Err(ProofError::AggregationProofV4Decode(format!(
            "unsupported packed public values encoding version {}",
            payload.public_values_encoding
        )));
    }
    let tx_public_inputs = decode_public_inputs_from_packed_public_values(
        &payload.packed_public_values,
        slot_tx_count,
        pub_inputs_len,
    )?;
    let derived_statement_commitment = statement_commitment_from_public_inputs(
        tx_public_inputs.get(..tx_count).ok_or_else(|| {
            ProofError::AggregationProofV4Binding(format!(
                "decoded slot public inputs {} shorter than block tx_count {}",
                tx_public_inputs.len(),
                tx_count
            ))
        })?,
    )?;
    if derived_statement_commitment != *expected_statement_commitment {
        return Err(ProofError::AggregationProofV4Binding(
            "statement commitment derived from aggregated public inputs does not match expected commitment"
                .to_string(),
        ));
    }

    let representative_proof: TransactionProofP3 = decode_postcard_exact(
        &payload.representative_proof,
        "representative proof",
    )
    .map_err(|_| {
        ProofError::AggregationProofV4Decode("representative proof encoding invalid".to_string())
    })?;
    if payload.outer_proof.is_empty() {
        if tx_count != 1 || slot_tx_count != 1 {
            return Err(ProofError::AggregationProofV4Decode(
                "outer aggregation proof missing".to_string(),
            ));
        }
        verify_transaction_proof_p3(
            &representative_proof,
            tx_public_inputs.first().ok_or_else(|| {
                ProofError::AggregationProofV4Decode(
                    "singleton aggregation payload missing public inputs".to_string(),
                )
            })?,
        )
        .map_err(|err| {
            ProofError::AggregationProofVerification(format!(
                "singleton representative proof verification failed: {err}"
            ))
        })?;
        return Ok(AggregationVerifyMetrics {
            cache_hit: false,
            cache_build_ms: 0,
            verify_batch_ms: 0,
            total_ms: start_total.elapsed().as_millis(),
        });
    }

    let shape = ProofShape {
        degree_bits: representative_proof.degree_bits,
        commit_phase_len: representative_proof
            .opening_proof
            .commit_phase_commits
            .len(),
        final_poly_len: representative_proof.opening_proof.final_poly.len(),
        query_count: representative_proof.opening_proof.query_proofs.len(),
    };
    let log_blowup = transaction_log_blowup_for_public_inputs(pub_inputs_len);
    let expected_shape_id = aggregation_shape_id(slot_tx_count, pub_inputs_len, log_blowup, shape);
    if payload.shape_id != expected_shape_id {
        return Err(ProofError::AggregationProofV4Binding(
            "shape_id mismatch".to_string(),
        ));
    }
    let cache_key = AggregationVerifierKey {
        tx_count: slot_tx_count,
        pub_inputs_len,
        log_blowup,
        shape,
    };
    let cache_result =
        get_or_build_aggregation_verifier_cache_entry(cache_key, &representative_proof)?;

    let outer_proof: BatchProof<Config> =
        decode_postcard_exact(&payload.outer_proof, "outer aggregation proof").map_err(|_| {
            ProofError::AggregationProofV4Decode(
                "outer aggregation proof encoding invalid".to_string(),
            )
        })?;
    let public_values = unpack_recursion_public_values(&payload.packed_public_values);
    if public_values.is_empty() {
        return Err(ProofError::AggregationProofV4Decode(
            "packed_public_values missing".to_string(),
        ));
    }

    let mut public_values_by_air = vec![Vec::new(); cache_result.entry.airs.len()];
    for idx in cache_result.entry.public_table_indices.iter().copied() {
        public_values_by_air[idx] = public_values.clone();
    }

    let start_verify = Instant::now();
    verify_batch(
        &cache_result.entry.outer_config,
        &cache_result.entry.airs,
        &outer_proof,
        &public_values_by_air,
        &cache_result.entry.common,
    )
    .map_err(|err| {
        ProofError::AggregationProofVerification(format!(
            "aggregation proof verification failed: {err:?}"
        ))
    })?;
    let verify_batch_ms = start_verify.elapsed().as_millis();

    let total_ms = start_total.elapsed().as_millis();
    tracing::info!(
        target: "consensus::metrics",
        tx_count,
        pub_inputs_len,
        cache_hit = cache_result.cache_hit,
        cache_build_ms = cache_result.cache_build_ms,
        verify_batch_ms,
        total_ms,
        "aggregation_verify_breakdown_metrics"
    );

    Ok(AggregationVerifyMetrics {
        cache_hit: cache_result.cache_hit,
        cache_build_ms: cache_result.cache_build_ms,
        verify_batch_ms,
        total_ms,
    })
}

pub fn verify_aggregation_proof(
    aggregation_proof: &[u8],
    tx_count: usize,
    expected_statement_commitment: &[u8; 48],
) -> Result<(), ProofError> {
    verify_aggregation_proof_with_metrics(
        aggregation_proof,
        tx_count,
        expected_statement_commitment,
    )
    .map(|_| ())
}

fn unpack_recursion_public_values(values: &[u64]) -> Vec<Val> {
    values.iter().map(|word| Val::from_u64(*word)).collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use p3_field::PrimeField64;

    fn pack_public_inputs_with_padding(
        tx_public_inputs: &[TransactionPublicInputsP3],
        per_tx_extension_values: usize,
    ) -> Vec<u64> {
        let mut packed = Vec::new();
        for public in tx_public_inputs {
            let values = public.to_vec();
            let values_len = values.len();
            assert!(values_len <= per_tx_extension_values);
            for value in values {
                packed.push(value.as_canonical_u64());
                packed.push(0);
            }
            for _ in values_len..per_tx_extension_values {
                packed.push(0);
                packed.push(0);
            }
        }
        packed
    }

    #[test]
    fn aggregation_proof_compression_roundtrip() {
        let raw = vec![42u8; 64 * 1024];
        let encoded = encode_aggregation_proof_bytes(raw.clone());
        let decoded = decode_aggregation_proof_bytes(&encoded).expect("decode");
        assert_eq!(decoded, raw);
        assert_eq!(aggregation_proof_uncompressed_len(&encoded), raw.len());
    }

    #[test]
    fn aggregation_proof_decode_passthrough() {
        let raw = vec![1u8, 2, 3, 4, 5, 6, 7, 8, 9];
        let decoded = decode_aggregation_proof_bytes(&raw).expect("decode");
        assert_eq!(decoded, raw);
    }

    #[test]
    fn exact_postcard_decoder_rejects_trailing_bytes() {
        #[derive(Debug, PartialEq, Eq, Serialize, Deserialize)]
        struct Sample {
            value: u64,
        }

        let mut encoded = postcard::to_allocvec(&Sample { value: 7 }).expect("encode");
        encoded.push(0xff);
        let err = decode_postcard_exact::<Sample>(&encoded, "sample")
            .expect_err("trailing bytes must be rejected");

        assert!(err.contains("trailing bytes"));
    }

    #[test]
    fn derive_statement_commitment_from_packed_public_values_roundtrip() {
        let mut tx0 = TransactionPublicInputsP3::default();
        tx0.input_flags[0] = Val::ONE;
        tx0.output_flags[0] = Val::ONE;
        tx0.merkle_root[0] = Val::from_u64(11);
        tx0.nullifiers[0][0] = Val::from_u64(12);
        tx0.commitments[0][0] = Val::from_u64(13);
        tx0.ciphertext_hashes[0][0] = Val::from_u64(14);
        tx0.fee = Val::from_u64(15);
        tx0.value_balance_sign = Val::ZERO;
        tx0.value_balance_magnitude = Val::from_u64(7);

        let mut tx1 = TransactionPublicInputsP3::default();
        tx1.input_flags[0] = Val::ONE;
        tx1.output_flags[0] = Val::ONE;
        tx1.merkle_root[0] = Val::from_u64(21);
        tx1.nullifiers[0][0] = Val::from_u64(22);
        tx1.commitments[0][0] = Val::from_u64(23);
        tx1.ciphertext_hashes[0][0] = Val::from_u64(24);
        tx1.fee = Val::from_u64(25);
        tx1.value_balance_sign = Val::ONE;
        tx1.value_balance_magnitude = Val::from_u64(9);

        let pub_inputs_len = tx0.to_vec().len();
        let per_tx_extension_values = pub_inputs_len + 4;
        let packed =
            pack_public_inputs_with_padding(&[tx0.clone(), tx1.clone()], per_tx_extension_values);

        let expected_hashes = vec![
            statement_hash_from_binding_hash(
                &binding_hash_from_public_inputs(&tx0).expect("binding hash"),
            ),
            statement_hash_from_binding_hash(
                &binding_hash_from_public_inputs(&tx1).expect("binding hash"),
            ),
        ];
        let expected_commitment =
            CommitmentBlockProver::commitment_from_statement_hashes(&expected_hashes)
                .expect("statement commitment");

        let observed =
            derive_statement_commitment_from_packed_public_values(&packed, 2, 2, pub_inputs_len)
                .expect("derived commitment");
        assert_eq!(observed, expected_commitment);
    }

    #[test]
    fn derive_statement_commitment_rejects_non_base_lifted_public_inputs() {
        let tx = TransactionPublicInputsP3::default();
        let pub_inputs_len = tx.to_vec().len();
        let mut packed = pack_public_inputs_with_padding(&[tx], pub_inputs_len + 2);
        packed[1] = 9; // second limb of first extension value must stay zero for base-lifted inputs.

        let err =
            derive_statement_commitment_from_packed_public_values(&packed, 1, 1, pub_inputs_len)
                .expect_err("non-base-lifted input should fail");
        assert!(matches!(err, ProofError::AggregationProofV4Binding(_)));
    }

    #[test]
    fn decode_public_inputs_from_packed_public_values_singleton_roundtrip() {
        let mut tx = TransactionPublicInputsP3::default();
        tx.input_flags[0] = Val::ONE;
        tx.output_flags[0] = Val::ONE;
        tx.merkle_root[0] = Val::from_u64(99);
        tx.nullifiers[0][0] = Val::from_u64(100);
        tx.commitments[0][0] = Val::from_u64(101);
        tx.ciphertext_hashes[0][0] = Val::from_u64(102);
        tx.fee = Val::from_u64(3);

        let pub_inputs_len = tx.to_vec().len();
        let packed = pack_public_inputs_with_padding(&[tx.clone()], pub_inputs_len);
        let decoded = decode_public_inputs_from_packed_public_values(&packed, 1, pub_inputs_len)
            .expect("decode packed singleton public inputs");
        assert_eq!(decoded.len(), 1);
        assert_eq!(decoded[0].to_vec(), tx.to_vec());
    }

    #[test]
    fn verify_aggregation_proof_rejects_legacy_payload_version() {
        let commitment = [0u8; 48];
        let payload = AggregationProofV4Payload {
            version: AGGREGATION_PROOF_FORMAT_VERSION_V4 - 1,
            proof_format: AGGREGATION_PROOF_FORMAT_VERSION_V4,
            tree_arity: 8,
            tree_levels: 1,
            root_level: 0,
            shape_id: [0u8; 32],
            tx_count: 1,
            tx_statements_commitment: commitment.to_vec(),
            public_values_encoding: AGGREGATION_PUBLIC_VALUES_ENCODING_V1,
            inner_public_inputs_len: 1,
            representative_proof: vec![0u8],
            packed_public_values: vec![0u64, 0u64],
            outer_proof: Vec::new(),
        };

        let encoded = postcard::to_allocvec(&payload).expect("encode");
        let err = verify_aggregation_proof(&encoded, 1, &commitment)
            .expect_err("legacy payload version must be rejected");
        assert!(matches!(
            err,
            ProofError::AggregationProofV4Decode(_) | ProofError::AggregationProofV5Decode(_)
        ));
    }

    #[test]
    fn verify_aggregation_proof_rejects_legacy_proof_format_id() {
        let commitment = [0u8; 48];
        let payload = AggregationProofV4Payload {
            version: AGGREGATION_PROOF_FORMAT_VERSION_V4,
            proof_format: AGGREGATION_PROOF_FORMAT_VERSION_V4 - 1,
            tree_arity: 8,
            tree_levels: 1,
            root_level: 0,
            shape_id: [0u8; 32],
            tx_count: 1,
            tx_statements_commitment: commitment.to_vec(),
            public_values_encoding: AGGREGATION_PUBLIC_VALUES_ENCODING_V1,
            inner_public_inputs_len: 1,
            representative_proof: vec![0u8],
            packed_public_values: vec![0u64, 0u64],
            outer_proof: Vec::new(),
        };

        let encoded = postcard::to_allocvec(&payload).expect("encode");
        let err = verify_aggregation_proof(&encoded, 1, &commitment)
            .expect_err("legacy payload format id must be rejected");
        assert!(matches!(
            err,
            ProofError::AggregationProofV4Decode(_) | ProofError::AggregationProofV5Decode(_)
        ));
    }

    #[test]
    fn verify_aggregation_proof_rejects_legacy_v4_by_default() {
        assert!(
            !legacy_v4_enabled(),
            "legacy V4 aggregation must not be runtime-enabled"
        );

        let commitment = [0u8; 48];
        let payload = AggregationProofV4Payload {
            version: AGGREGATION_PROOF_FORMAT_VERSION_V4,
            proof_format: AGGREGATION_PROOF_FORMAT_VERSION_V4,
            tree_arity: 8,
            tree_levels: 1,
            root_level: 0,
            shape_id: [0u8; 32],
            tx_count: 1,
            tx_statements_commitment: commitment.to_vec(),
            public_values_encoding: AGGREGATION_PUBLIC_VALUES_ENCODING_V1,
            inner_public_inputs_len: 1,
            representative_proof: vec![0u8],
            packed_public_values: vec![0u64, 0u64],
            outer_proof: Vec::new(),
        };

        let encoded = postcard::to_allocvec(&payload).expect("encode");
        let err = verify_aggregation_proof(&encoded, 1, &commitment)
            .expect_err("legacy V4 must be disabled by default");

        assert!(matches!(err, ProofError::AggregationProofV5Decode(_)));
        assert!(
            err.to_string()
                .contains("legacy V4 aggregation payloads are disabled")
        );
    }

    #[test]
    fn verify_aggregation_proof_rejects_legacy_v4_even_when_env_set() {
        assert!(
            !legacy_v4_enabled(),
            "HEGEMON_AGG_LEGACY_V4 must not re-enable legacy aggregation"
        );

        let commitment = [0u8; 48];
        let payload = AggregationProofV4Payload {
            version: AGGREGATION_PROOF_FORMAT_VERSION_V4,
            proof_format: AGGREGATION_PROOF_FORMAT_VERSION_V4,
            tree_arity: 8,
            tree_levels: 1,
            root_level: 0,
            shape_id: [0u8; 32],
            tx_count: 1,
            tx_statements_commitment: commitment.to_vec(),
            public_values_encoding: AGGREGATION_PUBLIC_VALUES_ENCODING_V1,
            inner_public_inputs_len: 1,
            representative_proof: vec![0u8],
            packed_public_values: vec![0u64, 0u64],
            outer_proof: Vec::new(),
        };

        let encoded = postcard::to_allocvec(&payload).expect("encode");
        let err = verify_aggregation_proof(&encoded, 1, &commitment)
            .expect_err("legacy V4 must stay disabled");

        assert!(matches!(err, ProofError::AggregationProofV5Decode(_)));
        assert!(
            err.to_string()
                .contains("legacy V4 aggregation payloads are disabled")
        );
    }

    #[test]
    fn derive_statement_commitment_uses_active_prefix_when_slots_are_padded() {
        let mut tx0 = TransactionPublicInputsP3::default();
        tx0.input_flags[0] = Val::ONE;
        tx0.output_flags[0] = Val::ONE;
        tx0.merkle_root[0] = Val::from_u64(31);
        tx0.nullifiers[0][0] = Val::from_u64(32);
        tx0.commitments[0][0] = Val::from_u64(33);
        tx0.ciphertext_hashes[0][0] = Val::from_u64(34);

        let mut tx1 = TransactionPublicInputsP3::default();
        tx1.input_flags[0] = Val::ONE;
        tx1.output_flags[0] = Val::ONE;
        tx1.merkle_root[0] = Val::from_u64(41);
        tx1.nullifiers[0][0] = Val::from_u64(42);
        tx1.commitments[0][0] = Val::from_u64(43);
        tx1.ciphertext_hashes[0][0] = Val::from_u64(44);

        let pub_inputs_len = tx0.to_vec().len();
        let per_tx_extension_values = pub_inputs_len + 2;
        let packed = pack_public_inputs_with_padding(
            &[tx0.clone(), tx1.clone(), tx1.clone(), tx1.clone()],
            per_tx_extension_values,
        );

        let expected_hashes = vec![
            statement_hash_from_binding_hash(
                &binding_hash_from_public_inputs(&tx0).expect("binding hash"),
            ),
            statement_hash_from_binding_hash(
                &binding_hash_from_public_inputs(&tx1).expect("binding hash"),
            ),
        ];
        let expected_commitment =
            CommitmentBlockProver::commitment_from_statement_hashes(&expected_hashes)
                .expect("statement commitment");

        let observed =
            derive_statement_commitment_from_packed_public_values(&packed, 4, 2, pub_inputs_len)
                .expect("derive commitment from padded slots");
        assert_eq!(observed, expected_commitment);
    }

    #[test]
    fn validate_payload_header_rejects_excessive_slot_padding() {
        let commitment = [7u8; 48];
        let payload = AggregationProofV4Payload {
            version: AGGREGATION_PROOF_FORMAT_VERSION_V4,
            proof_format: AGGREGATION_PROOF_FORMAT_VERSION_V4,
            tree_arity: 8,
            tree_levels: 2,
            root_level: 1,
            shape_id: [0u8; 32],
            tx_count: 17,
            tx_statements_commitment: commitment.to_vec(),
            public_values_encoding: AGGREGATION_PUBLIC_VALUES_ENCODING_V1,
            inner_public_inputs_len: 1,
            representative_proof: vec![0],
            packed_public_values: vec![0, 0],
            outer_proof: vec![0],
        };

        let err = validate_payload_header(&payload, 1, &commitment)
            .expect_err("slot padding beyond factor bound must fail");
        assert!(matches!(err, ProofError::AggregationProofV4Binding(_)));
    }
}
