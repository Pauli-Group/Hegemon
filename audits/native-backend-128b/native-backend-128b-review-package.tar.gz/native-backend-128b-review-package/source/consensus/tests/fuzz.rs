mod common;

use common::{BftBlockParams, assemble_bft_block, make_validators, validator_set};
use consensus::proof::HashVerifier;
use consensus::{
    BftConsensus, CommitmentTreeState, DEFAULT_VERSION_BINDING, NullifierSet, Transaction,
};
use proptest::{prelude::*, test_runner::Config as ProptestConfig};

fn has_duplicates(values: &[[u8; 48]]) -> bool {
    use std::collections::BTreeSet;
    let mut set = BTreeSet::new();
    for value in values {
        if !set.insert(*value) {
            return true;
        }
    }
    false
}

proptest! {
    #![proptest_config(ProptestConfig::with_cases(64))]
    #[test]
    #[ignore = "manual adversarial property test; run when changing consensus validation"]
    fn duplicate_nullifiers_cause_rejection(nullifiers in proptest::collection::vec(any::<[u8; 48]>(), 2..5)) {
        let duplicates = has_duplicates(&nullifiers);
        let validators = make_validators(3, 10);
        let validator_set = validator_set(&validators);
        let genesis_tree = CommitmentTreeState::default();
        let mut consensus = BftConsensus::new(validator_set, genesis_tree.clone(), HashVerifier);
        let transaction = Transaction::new(
            nullifiers.clone(),
            vec![[9u8; 48]],
            [7u8; 48],
            DEFAULT_VERSION_BINDING,
            vec![],
        );
        let result = assemble_bft_block(BftBlockParams {
            height: 1,
            view: 1,
            parent_hash: [0u8; 32],
            timestamp_ms: 1234,
            transactions: vec![transaction],
            validators: &validators,
            signer_indices: &[0, 1, 2],
            base_nullifiers: &NullifierSet::new(),
            base_commitment_tree: &genesis_tree,
            supply_digest: 0,
        });
        if duplicates {
            prop_assert!(result.is_err());
        } else {
            let (block, _, _) = result.expect("block assembly");
            prop_assert!(consensus.apply_block(block).is_ok());
        }
    }
}
