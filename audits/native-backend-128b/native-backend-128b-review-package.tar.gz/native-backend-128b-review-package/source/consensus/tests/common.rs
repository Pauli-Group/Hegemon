#![allow(dead_code)]
use consensus::BalanceTag;
use consensus::CoinbaseData;
use consensus::CoinbaseSource;
use consensus::CommitmentTreeState;
use consensus::DEFAULT_VERSION_BINDING;
use consensus::ProofError;
use consensus::SupplyDigest;
use consensus::VersionBinding;
use consensus::error::ConsensusError;
use consensus::header::{BlockHeader, PowSeal};
use consensus::nullifier::NullifierSet;
use consensus::reward::{block_subsidy, update_supply_digest};
use consensus::types::{
    ConsensusBlock, DaParams, Transaction, compute_fee_commitment, compute_proof_commitment,
    compute_version_commitment, da_root,
};
use consensus::validator::{Validator, ValidatorSet};
use crypto::hashes::blake3_384;
use crypto::ml_dsa::{ML_DSA_SIGNATURE_LEN, MlDsaSecretKey};
use crypto::traits::{SigningKey, VerifyKey};

#[derive(Clone)]
pub struct TestValidator {
    pub validator: Validator,
    pub secret: MlDsaSecretKey,
}

pub struct BftBlockParams<'a> {
    pub height: u64,
    pub view: u64,
    pub parent_hash: [u8; 32],
    pub timestamp_ms: u64,
    pub transactions: Vec<Transaction>,
    pub validators: &'a [TestValidator],
    pub signer_indices: &'a [usize],
    pub base_nullifiers: &'a NullifierSet,
    pub base_commitment_tree: &'a CommitmentTreeState,
    pub supply_digest: SupplyDigest,
}

pub struct PowBlockParams<'a> {
    pub height: u64,
    pub parent_hash: [u8; 32],
    pub timestamp_ms: u64,
    pub transactions: Vec<Transaction>,
    pub miner: &'a TestValidator,
    pub base_nullifiers: &'a NullifierSet,
    pub base_commitment_tree: &'a CommitmentTreeState,
    pub pow_bits: u32,
    pub nonce: [u8; 32],
    pub parent_supply: SupplyDigest,
    pub coinbase: CoinbaseData,
}

pub fn make_validators(count: usize, stake: u64) -> Vec<TestValidator> {
    (0..count)
        .map(|idx| {
            let mut seed = Vec::from(b"validator-");
            seed.extend_from_slice(idx.to_be_bytes().as_slice());
            let secret = MlDsaSecretKey::generate_deterministic(&seed);
            let validator = Validator::new(secret.verify_key(), stake);
            TestValidator { validator, secret }
        })
        .collect()
}

pub fn validator_set(validators: &[TestValidator]) -> ValidatorSet {
    ValidatorSet::new(validators.iter().map(|v| v.validator.clone()).collect())
}

#[allow(dead_code)]
pub fn dummy_transaction(tag_seed: u8) -> Transaction {
    dummy_transaction_with_version(tag_seed, DEFAULT_VERSION_BINDING)
}

pub fn dummy_transaction_with_version(tag_seed: u8, version: VersionBinding) -> Transaction {
    let nullifier = [tag_seed; 48];
    let commitment = [tag_seed.wrapping_add(1); 48];
    let balance_tag: BalanceTag = [tag_seed.wrapping_add(2); 48];
    Transaction::new(
        vec![nullifier],
        vec![commitment],
        balance_tag,
        version,
        vec![],
    )
}

pub fn dummy_coinbase(height: u64) -> CoinbaseData {
    CoinbaseData {
        minted: block_subsidy(height),
        fees: 0,
        burns: 0,
        source: CoinbaseSource::BalanceTag([0u8; 48]),
    }
}

pub fn apply_nullifiers(
    base: &NullifierSet,
    transactions: &[Transaction],
) -> Result<NullifierSet, ConsensusError> {
    let mut set = base.clone();
    for tx in transactions {
        for nf in &tx.nullifiers {
            set.insert(*nf)?;
        }
    }
    Ok(set)
}

pub fn assemble_bft_block(
    params: BftBlockParams<'_>,
) -> Result<(ConsensusBlock, NullifierSet, CommitmentTreeState), ConsensusError> {
    let BftBlockParams {
        height,
        view,
        parent_hash,
        timestamp_ms,
        transactions,
        validators,
        signer_indices,
        base_nullifiers,
        base_commitment_tree,
        supply_digest,
    } = params;
    let new_nullifiers = apply_nullifiers(base_nullifiers, &transactions)?;
    let nullifier_root = new_nullifiers.commitment();
    let proof_commitment = compute_proof_commitment(&transactions);
    let version_commitment = compute_version_commitment(&transactions);
    let fee_commitment = compute_fee_commitment(&transactions);
    let mut tree = base_commitment_tree.clone();
    for tx in &transactions {
        for commitment in tx.commitments.iter().copied().filter(|c| *c != [0u8; 48]) {
            tree.append(commitment).map_err(ProofError::from)?;
        }
    }
    let state_root = tree.root();
    let da_params = DaParams {
        chunk_size: 1024,
        sample_count: 4,
    };
    let validator_set = validator_set(validators);
    let da_root = da_root(&transactions, da_params).expect("da root");
    let mut header = BlockHeader {
        version: 1,
        height,
        view,
        timestamp_ms,
        parent_hash,
        state_root,
        kernel_root: kernel_root_from_shielded_root(&state_root),
        nullifier_root,
        proof_commitment,
        da_root,
        da_params,
        version_commitment,
        tx_count: transactions.len() as u32,
        fee_commitment,
        supply_digest,
        validator_set_commitment: validator_set.validator_set_commitment(),
        signature_aggregate: Vec::new(),
        signature_bitmap: Some(vec![0u8; validators.len().div_ceil(8)]),
        pow: None,
    };
    let signing_hash = header.signing_hash()?;
    let mut aggregate = Vec::with_capacity(signer_indices.len() * ML_DSA_SIGNATURE_LEN);
    let mut bitmap = header.signature_bitmap.clone().expect("bitmap initialized");
    for &idx in signer_indices {
        let validator = &validators[idx];
        let signature = validator.secret.sign(&signing_hash);
        aggregate.extend_from_slice(&signature.to_bytes());
        bitmap[idx / 8] |= 1 << (idx % 8);
    }
    header.signature_aggregate = aggregate;
    header.signature_bitmap = Some(bitmap);
    Ok((
        ConsensusBlock {
            header,
            transactions,
            coinbase: None,
            proven_batch: None,
            block_artifact: None,
            tx_validity_claims: None,
            tx_statements_commitment: None,
            proof_verification_mode: consensus::types::ProofVerificationMode::InlineRequired,
        },
        new_nullifiers,
        tree,
    ))
}

#[allow(dead_code)]
pub fn assemble_pow_block(
    params: PowBlockParams<'_>,
) -> Result<(ConsensusBlock, NullifierSet, CommitmentTreeState), ConsensusError> {
    let PowBlockParams {
        height,
        parent_hash,
        timestamp_ms,
        transactions,
        miner,
        base_nullifiers,
        base_commitment_tree,
        pow_bits,
        nonce,
        parent_supply,
        coinbase,
    } = params;
    let new_nullifiers = apply_nullifiers(base_nullifiers, &transactions)?;
    let nullifier_root = new_nullifiers.commitment();
    let proof_commitment = compute_proof_commitment(&transactions);
    let version_commitment = compute_version_commitment(&transactions);
    let fee_commitment = compute_fee_commitment(&transactions);
    let mut tree = base_commitment_tree.clone();
    for tx in &transactions {
        for commitment in tx.commitments.iter().copied().filter(|c| *c != [0u8; 48]) {
            tree.append(commitment).map_err(ProofError::from)?;
        }
    }
    let state_root = tree.root();
    let da_params = DaParams {
        chunk_size: 1024,
        sample_count: 4,
    };
    let da_root = da_root(&transactions, da_params).expect("da root");
    let mut header = BlockHeader {
        version: 1,
        height,
        view: height,
        timestamp_ms,
        parent_hash,
        state_root,
        kernel_root: kernel_root_from_shielded_root(&state_root),
        nullifier_root,
        proof_commitment,
        da_root,
        da_params,
        version_commitment,
        tx_count: transactions.len() as u32,
        fee_commitment,
        supply_digest: update_supply_digest(parent_supply, coinbase.net_native_delta())
            .expect("supply digest"),
        validator_set_commitment: blake3_384(&miner.validator.public_key().to_bytes()),
        signature_aggregate: Vec::new(),
        signature_bitmap: None,
        pow: Some(PowSeal { nonce, pow_bits }),
    };
    let signing_hash = header.signing_hash()?;
    let signature = miner.secret.sign(&signing_hash);
    header.signature_aggregate = signature.to_bytes().to_vec();
    Ok((
        ConsensusBlock {
            header,
            transactions,
            coinbase: Some(coinbase),
            proven_batch: None,
            block_artifact: None,
            tx_validity_claims: None,
            tx_statements_commitment: None,
            proof_verification_mode: consensus::types::ProofVerificationMode::InlineRequired,
        },
        new_nullifiers,
        tree,
    ))
}

fn kernel_root_from_shielded_root(root: &[u8; 48]) -> [u8; 48] {
    let mut bytes = Vec::with_capacity(24 + 2 + 48);
    bytes.extend_from_slice(b"hegemon-kernel-root-v1");
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(root);
    blake3_384(&bytes)
}

#[allow(dead_code)]
pub fn empty_nullifier_root() -> [u8; 48] {
    NullifierSet::new().commitment()
}
